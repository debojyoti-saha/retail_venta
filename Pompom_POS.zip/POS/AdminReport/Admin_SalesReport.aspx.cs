﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;
using System.Web.UI.DataVisualization.Charting;

public partial class Report_SalesReport : System.Web.UI.Page
{
    DBClass db = new DBClass();
    protected void Page_Load(object sender, EventArgs e)
    {

        string current_Year = DateTime.Now.Year.ToString(), previous_Year = (Convert.ToInt32(DateTime.Now.Year.ToString()) - 1).ToString();
 
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
    }
}