﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Retail.DAL;

public partial class Report_CustomerSales : System.Web.UI.Page
{
    DBClass db = new DBClass();
    GlobalClass gc = new GlobalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnExport);
        ScriptManager.RegisterStartupScript(this, this.GetType(), "do", "javascript:_do_task();", true);
        if (!IsPostBack)
        {
            gc.FillDropDown(ddlBranch, "spFillMaster 'branch'", "BranchName", "BranchId", "-- Select Branch --");
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        gvAgeWiseDetails.Visible = false;
        gvTimeWiseDetails.Visible = false;

        SqlParameterCollection paracol = new SqlCommand().Parameters;
        SqlParameter para;

        para = new SqlParameter();
        para.ParameterName = "@MODE";
        para.Value = rbtnSearchMode.SelectedValue.ToString();
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@FROM_DATE";
        para.Value = txtFromDate.Text.Trim();
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@TO_DATE";
        para.Value = txtTodate.Text.Trim();
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@BRANCH";
        para.Value = ddlBranch.SelectedValue.ToString();
        paracol.Add(para);

        DataTable dt = db.ExecuteSpForDT("SP_GET_CUSTOMER_SALE_REPORT", paracol);
        Session["CustomerSalesReport_dt"] = dt;

        if (rbtnSearchMode.SelectedValue.ToString() == "1")
        {
            gvAgeWiseDetails.DataSource = dt;
            gvAgeWiseDetails.DataBind();

            gvAgeWiseDetails.Visible = true;
        }
        else if (rbtnSearchMode.SelectedValue.ToString() == "2")
        {
            gvTimeWiseDetails.DataSource = dt;
            gvTimeWiseDetails.DataBind();

            gvTimeWiseDetails.Visible = true;
        }
    }
    protected void gvAgeWiseDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvAgeWiseDetails.PageIndex = e.NewPageIndex;
        gvAgeWiseDetails.DataSource = Session["CustomerSalesReport_dt"];
        gvAgeWiseDetails.DataBind();
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = ((DataTable)Session["CustomerSalesReport_dt"]).Copy();
            db.ExportToExcel(dt, "CustomerSalesReport.xls");
        }
        catch
        {
            return;
        }
    }
}