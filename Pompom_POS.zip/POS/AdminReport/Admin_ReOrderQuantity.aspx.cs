﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;

public partial class Report_ReOrderQuantity : System.Web.UI.Page
{
    DBClass db = new DBClass();
    GlobalClass gc = new GlobalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnExport);

        if (!IsPostBack)
        {
            gc.FillDropDown(ddlBranch, "spFillMaster 'branch'", "BranchName", "BranchId", "-- Select Branch --");
            FillData("","");
        }
    }
    public void FillData(string searchmode, string searchtext)
    {
        DataTable dt = db.getDataTable("SP_GET_REORDER_QUANTITY_REPORT '" + searchmode + "','" + searchtext + "'," + ddlBranch.SelectedValue.ToString());
        Session["ReOrderQty_dt"] = dt;
        gvItemDetails.DataSource = dt;
        gvItemDetails.DataBind();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        FillData(ddlSearchType.SelectedValue.ToString(), txtSearchText.Text.Trim());
    }
    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = ((DataTable)Session["ReOrderQty_dt"]).Copy();

            db.ExportToExcel(dt, "ReOrderQantityReport.xls");
        }
        catch
        {
            return;
        }
    }
    protected void gvItemDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvItemDetails.PageIndex = e.NewPageIndex;
        gvItemDetails.DataSource = Session["ReOrderQty_dt"];
        gvItemDetails.DataBind();
    }
}