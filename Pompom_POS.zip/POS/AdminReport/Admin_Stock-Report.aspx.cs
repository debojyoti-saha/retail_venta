﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;
using System.Web.UI.DataVisualization.Charting;
using System.Drawing;
using Microsoft.Reporting.WebForms;

public partial class Report_Inventory_Stock_Report : System.Web.UI.Page
{
    DBClass db = new DBClass();
    GlobalClass gc = new GlobalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        //Chart1.Width = Request.Browser.ScreenPixelsWidth * 2;
        //Chart1.Height = Request.Browser.ScreenPixelsHeight;

        //Chart1.Titles["text"].Text = "Top 20 Product Stock";
        //Chart1.Titles["text"].Font = new Font("Helvetica", 20, FontStyle.Bold);
        //Chart1.Titles["text"].TextStyle = TextStyle.Frame;
        //Chart1.Series["Series1"].ChartType = SeriesChartType.Column;
        //Chart1.Series["Series1"]["DrawingStyle"] = "Emboss";

        //Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
        //Chart1.Series["Series1"].IsValueShownAsLabel = true;

        //// Setting the X Axis
        //Chart1.ChartAreas["ChartArea1"].AxisX.IsMarginVisible = true;
        //Chart1.ChartAreas["ChartArea1"].AxisX.Interval = 1;
        //Chart1.ChartAreas["ChartArea1"].AxisX.Maximum = Double.NaN;
        //Chart1.ChartAreas["ChartArea1"].AxisX.Title = "Products";
        //Chart1.ChartAreas["ChartArea1"].AxisX.TitleFont = new Font("Sans Serif", 10, FontStyle.Bold);

        //// Setting the Y Axis
        //Chart1.ChartAreas["ChartArea1"].AxisY.Interval = 500;
        //Chart1.ChartAreas["ChartArea1"].AxisY.Maximum = Double.NaN;
        //Chart1.ChartAreas["ChartArea1"].AxisY.Title = "Quantity [Pcs]";
        //Chart1.ChartAreas["ChartArea1"].AxisY.TitleFont = new Font("Sans Serif", 10, FontStyle.Regular);

        //DataTable dt = db.getDataTable("SP_GET_CURRENT_TOP_STOCK "+Request.Cookies["UserCookies"]["Branch"]);

        ////double[] yValues = dt.Columns["Qty1"].
        ////string[] xValues = { "Used Space (#PERCENT{P0} or #VAL Bytes)", "Free Space (#PERCENT{P0} or #VAL Bytes)" };


        //Chart1.DataSource = dt;
        ////Legend legend = new Legend(dt.Columns["PrintName"].ColumnName);
        ////Chart1.Legends.Add(legend);

        ////Chart1.Series["Series1"].AxisLabel = "#VALY";
        //Chart1.Series["Series1"].XValueMember = "PrintName";
        //Chart1.Series["Series1"].YValueMembers = "QTY1";
        //Chart1.DataBind();


        if (!IsPostBack)
        {
            gc.FillDropDown(ddlBranch, "spFillMaster 'branch'", "BranchName", "BranchId", "-- Select Branch --");
        }
    }
    protected void Tab_ActiveTabChanged(object sender, EventArgs e)
    {
        showChart();

    }

    protected void fillData(DataTable dt, string _Parameter)
    {
        DataTable dsStockReport = dt;
        ReportParameter Para;
        if (Tab.ActiveTabIndex == 0)
        {
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/StockReport.rdlc");
            Para = new ReportParameter("ReportParameter1", _Parameter);
            ReportViewer1.LocalReport.SetParameters(Para);
            ReportDataSource datasource1 = new ReportDataSource("dsStockReport", dsStockReport);
            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(datasource1);
            ReportViewer1.DataBind();
            ReportViewer1.ServerReport.Refresh();
        }
        if (Tab.ActiveTabIndex == 1)
        {
            ReportViewer2.ProcessingMode = ProcessingMode.Local;
            ReportViewer2.LocalReport.ReportPath = Server.MapPath("~/Report/PieStockReport.rdlc");
            Para = new ReportParameter("ReportParameter1", _Parameter);
            ReportViewer1.LocalReport.SetParameters(Para);
            ReportDataSource datasource1 = new ReportDataSource("dsStockReport", dsStockReport);
            ReportViewer2.LocalReport.DataSources.Clear();
            ReportViewer2.LocalReport.DataSources.Add(datasource1);
            ReportViewer2.ServerReport.Refresh();
        }
        else if (Tab.ActiveTabIndex == 2)
        {
            ReportViewer3.ProcessingMode = ProcessingMode.Local;
            ReportViewer3.LocalReport.ReportPath = Server.MapPath("~/Report/GridStockReport.rdlc");
            Para = new ReportParameter("ReportParameter1", _Parameter);
            ReportViewer1.LocalReport.SetParameters(Para);
            ReportDataSource datasource1 = new ReportDataSource("dsStockReport", dsStockReport);
            ReportViewer3.LocalReport.DataSources.Clear();
            ReportViewer3.LocalReport.DataSources.Add(datasource1);
            ReportViewer3.ServerReport.Refresh();
        }
    }

    protected void ddlSearchType_SelectedIndexChanged(object sender, EventArgs e)
    {
        

        if (ddlSearchType.SelectedValue == "3")
        {
            pnlSingleProductStockContainer.Visible = true;
            pnlMonthWiseProductStockContainer.Visible = false;
        }
        else if (ddlSearchType.SelectedValue == "4")
        {
            pnlMonthWiseProductStockContainer.Visible = true;
            pnlSingleProductStockContainer.Visible = false;
        }
        else
        {
            pnlMonthWiseProductStockContainer.Visible = false;
            pnlSingleProductStockContainer.Visible = false;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Tab.ActiveTabIndex = 0;
        showChart();
    }

    private void showChart()
    {
        pnlTopStock.Visible = true;

        if (ddlSearchType.SelectedValue == "1")
        {
            DataTable dt = db.getDataTable("SP_GET_CURRENT_TOP_STOCK '1','',''," + ddlBranch.SelectedValue.ToString());
            fillData(dt, "Top 20 Products Stock [Current]");
        }

        if (ddlSearchType.SelectedValue == "2")
        {
            DataTable dt = db.getDataTable("SP_GET_CURRENT_TOP_STOCK '2','',''," + ddlBranch.SelectedValue.ToString());
            fillData(dt, "Bottom 20 Products Stock [Current]");
        }

        if (ddlSearchType.SelectedValue == "3")
        {
            DataTable dt = db.getDataTable("SP_GET_CURRENT_TOP_STOCK '3','" + txtSingleProductCode.Text.Trim() + "',''," + ddlBranch.SelectedValue.ToString());
            fillData(dt, "Single Products( "+txtSingleProductCode.Text.Trim()+" ) Stock [Current]");
        }

        else if (ddlSearchType.SelectedValue == "4")
        {
            DataTable dt = db.getDataTable("SP_GET_CURRENT_TOP_STOCK '4','" + ddlYear.SelectedValue.Trim() + "',''," + ddlBranch.SelectedValue.ToString());
            fillData(dt, "Month Wise Purchase Stcok details for the Year of " + ddlYear.SelectedValue.Trim());
        }
    }
    protected void ReportViewer1_ReportRefresh(object sender, System.ComponentModel.CancelEventArgs e)
    {
        showChart();
    }
}