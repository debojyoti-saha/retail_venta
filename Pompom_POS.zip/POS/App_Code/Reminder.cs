﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using Retail.DAL;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Reminder
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class Reminder : System.Web.Services.WebService {

    public Reminder () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    DBClass db = new DBClass();
    [WebMethod]
    public List<customer> getAllCustomer()
    {
        List<customer> list = new List<customer>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_ALL_CUSTOMER '" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new customer
            {
                customerCode = dt.Rows[i]["CustomerCode"].ToString()
                ,
                customerName = dt.Rows[i]["customerName"].ToString()
            });
        }
        return list;
    }

    public class customer
    {
        public string customerCode { get; set; }
        public string customerName { get; set; }
    }
}
