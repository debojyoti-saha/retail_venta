﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Retail.DAL;
using System.Data;



/// <summary>
/// Summary description for AccountsService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class AccountsService : System.Web.Services.WebService
{
    DBClass db = new DBClass();
    public AccountsService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod(EnableSession = true)]
    public List<account> GetAccounts(string type)
    {

        List<account> accounts = new List<account>();

        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_SELECT_ACCOUNT 1");

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            accounts.Add(new account
            {
                AccountCode = dt.Rows[i]["AccountCode"].ToString()
                ,
                AccountName = dt.Rows[i]["AccountName"].ToString()
                ,
                Alias = dt.Rows[i]["Alias"].ToString()
            });
        }

        return accounts;
    }

    [WebMethod(EnableSession = true)]
    public List<account> GetAccountsByType(string type, string branch)
    {

        List<account> accounts = new List<account>();

        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_SELECT_LEDGER_BY_TYPE '" + type + "','" + branch + "'");

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            accounts.Add(new account
            {
                AccountCode = dt.Rows[i]["ID"].ToString()
                ,
                AccountName = dt.Rows[i]["Ledger_name"].ToString()
                ,
                Alias = dt.Rows[i]["Alias"].ToString()
            });
        }

        return accounts;
    }


    public class account
    {
        public string AccountCode { get; set; }
        public string AccountName { get; set; }
        public string Alias { get; set; }
    }
}
