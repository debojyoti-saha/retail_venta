﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Retail.DAL;
using System.Data;
using System.Configuration;
using System.Web.Script.Serialization;

/// <summary>
/// Summary description for LoginAPIService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class LoginAPIService : System.Web.Services.WebService
{

    public LoginAPIService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    DBClass db = new DBClass();
    [WebMethod]
    public string GetRegistration(string Fname, string Lname, string Email, string Uid)
    {
        if (Email == "")
        {
            DataTable dt = db.getDataTable("SP_LOGIN_API 'Facebook','" + Fname + "','" + Lname + "','" + Email + "','','" + Uid + "'");
        }
        else
        {
            throw new Exception("You are not permit to signup. Please insert a email address on your facebook id.");
        }
        return "success";
    }

    [WebMethod]
    public string GetConfigForLocal()
    {
        string val = "opps! you are in wrong place. Invalid Data";
        string headerValues = HttpContext.Current.Request.Headers.GetValues("environment").First();
        if (headerValues == ConfigurationManager.AppSettings["token"])
        {
            OfflineConfig config = new OfflineConfig();
            string connectionstring = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            DataTable dt_info = db.getDataTable("select top 1 [SalesBillMinDays], [SalesReturnMinDays] from tblCompany where companycode=01");
            Cryptography crypto = new Cryptography();

            config.connectionString = connectionstring;
            config.minSalesDays = dt_info.Rows[0]["SalesBillMinDays"].ToString();
            config.minSalesReturnDays = dt_info.Rows[0]["SalesReturnMinDays"].ToString();

            val = crypto.Encrypt_SHA(new JavaScriptSerializer().Serialize(config), true);
        }
        return val;
    }
}
