﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Retail.DAL;
using System.Data.SqlClient;
using System.Data;


[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
[System.Web.Script.Services.ScriptService]
public class Master : System.Web.Services.WebService {
    DBClass db = new DBClass();
    public Master () {

    }

    [WebMethod(EnableSession = true)]
    public List<item> GetProduct(string Product)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTOFILL 'PRODUCT','" + Product + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _description = dt.Rows[i]["PRODUCT"].ToString()
            });
        }
        return list;
    }
    [WebMethod(EnableSession = true)]
    public List<item> GetBrand(string brandcode)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTOFILL 'BRAND','" + brandcode + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _description = dt.Rows[i]["Brand"].ToString()
            });
        }
        return list;
    }
    [WebMethod(EnableSession = true)]
    public List<item> GetSize(string sizecode)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTOFILL 'SIZE','" + sizecode + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _description = dt.Rows[i]["Size"].ToString()
            });
        }
        return list;
    }
    [WebMethod(EnableSession = true)]
    public List<item> GetColor(string color)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTOFILL 'COLOR','" + color + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _description = dt.Rows[i]["COLOR"].ToString()
            });
        }
        return list;
    }
    [WebMethod(EnableSession = true)]
    public List<item> GetDesign(string design)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTOFILL 'DESIGN','" + design + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _description = dt.Rows[i]["DESIGN"].ToString()
            });
        }
        return list;
    }
    [WebMethod(EnableSession = true)]
    public List<item> GetCategory(string category)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTOFILL 'CATEGORY','" + category + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _description = dt.Rows[i]["CATEGORY"].ToString()
            });
        }
        return list;
    }
    public class item
    {
        public string _ID { get; set; }
        public string _description { get; set; }
    }
}
