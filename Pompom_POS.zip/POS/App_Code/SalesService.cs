﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using Retail.DAL;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for SalesService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class SalesService : System.Web.Services.WebService
{
    DBClass db = new DBClass();
    Cryptography cr = new Cryptography();
    EmailSender emailsender = new EmailSender();
    public SalesService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod(EnableSession = true)]
    public List<item> GetProductManual(string productcode, string mode)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SALES_ITEM '" + mode + "','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "','" + productcode + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _itemId = dt.Rows[i]["ItemId"].ToString()
                ,
                //_id = dt.Rows[i]["ProductCode"].ToString()
                //,
                _description = dt.Rows[i]["Description"].ToString()
                ,
                _barcode = dt.Rows[i]["BarcodeNo"].ToString()
                ,
                //_color = dt.Rows[i]["ColorName"].ToString()
                //,
                //_size = dt.Rows[i]["SizeName"].ToString()
                //,
                //_brand = dt.Rows[i]["BrandName"].ToString()
                //,
                //_design = dt.Rows[i]["DesignName"].ToString()
                //,
                //_category = dt.Rows[i]["CategoryName"].ToString()
                //,
                _unit = dt.Rows[i]["Unit"].ToString()
                ,
                _purchaseRate = dt.Rows[i]["PurchaseRate"].ToString()
                ,
                _saleRate = dt.Rows[i]["SaleRate"].ToString()
                ,
                _mrp = dt.Rows[i]["MRP"].ToString()
                ,
                _tax = dt.Rows[i]["Tax"].ToString()
                ,
                _qty = dt.Rows[i]["QTY"].ToString()
                ,
                _qtyType = dt.Rows[i]["QtyType"].ToString()
                ,
                _disc = dt.Rows[i]["DiscountPercent"].ToString()
            });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<returnItem> GetProductReturn(string barcode, string invoice)
    {
        List<returnItem> list = new List<returnItem>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SALES_RETURN_ITEM '" + barcode + "','" + invoice + "'");
        if (dt.Rows.Count > 0)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                list.Add(new returnItem
                {
                    _itemId = dt.Rows[i]["ItemId"].ToString()
                    ,
                    _id = dt.Rows[i]["ProductCode"].ToString()
                    ,
                    _description = dt.Rows[i]["Description"].ToString()
                    ,
                    _barcode = dt.Rows[i]["BarcodeNo"].ToString()
                    ,
                    _color = dt.Rows[i]["ColorName"].ToString()
                    ,
                    _size = dt.Rows[i]["SizeName"].ToString()
                    //,
                    //_unit = dt.Rows[i]["Unit"].ToString()
                    ,
                    _disPercent = dt.Rows[i]["DisPercentage"].ToString()
                    ,
                    _saleRate = dt.Rows[i]["SaleRate"].ToString()
                    ,
                    _mrp = dt.Rows[i]["MRP"].ToString()
                    ,
                    _tax = dt.Rows[i]["Tax"].ToString()
                    ,
                    _qty = dt.Rows[i]["QTY"].ToString()
                    ,
                    _qtyType = dt.Rows[i]["QtyType"].ToString()
                    ,
                    _amount = dt.Rows[i]["TotalAmount"].ToString()

                });
            }
        }
        else
        {
            throw new Exception("Item barcode not found or its already returned or exceeds bill Quantity!");
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public string GenerateBill(product product)
    {
        string BillNo = "";

        DataTable dt_sales_details = new DataTable();
        dt_sales_details.Columns.Add("Id");
        dt_sales_details.Columns.Add("Barcode");
        dt_sales_details.Columns.Add("Amount");
        dt_sales_details.Columns.Add("Discount");
        dt_sales_details.Columns.Add("Qtr");
        dt_sales_details.AcceptChanges();

        List<pro> pr = product.pro;

        foreach (pro p in pr)
        {
            DataRow dr = dt_sales_details.NewRow();
            dr[0] = p.Id;
            dr[1] = p.Barcode;
            dr[2] = p.Amount;
            dr[3] = p.Discount;
            dr[4] = p.Qtr;


            dt_sales_details.Rows.Add(dr);
            dt_sales_details.AcceptChanges();
        }



        SqlParameterCollection paracol = new SqlCommand().Parameters;
        SqlParameter para;

        para = new SqlParameter();
        para.ParameterName = "@SALES_DETAILS";
        para.Value = dt_sales_details;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@REF_NO";
        para.Value = product.pay.RefNo;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_FNAME";
        para.Value = product.pay.CustFName;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_MNAME";
        para.Value = product.pay.CustMName;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_LNAME";
        para.Value = product.pay.CustLName;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_ADDRESS";
        para.Value = product.pay.CustAddress;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_MOBILE";
        para.Value = product.pay.CustMobile;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_DOB";
        para.Value = product.pay.CustDOB;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_AGE";
        para.Value = product.pay.Age;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_ANNI";
        para.Value = product.pay.Anniversary;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CUST_GENDER";
        para.Value = product.pay.Gender;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CASH";
        para.Value = product.pay.Cash;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CARD";
        para.Value = product.pay.Card;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@POINTS";
        para.Value = product.pay.Points;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@POINTS_VALUATION";
        para.Value = product.pay.PointsValue;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@TAX";
        para.Value = product.pay.Tax;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@DISCOUNT";
        para.Value = product.pay.Discount;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@SALES_DATE";
        para.Value = product.pay.SalesDate;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CARD_NO";
        para.Value = product.pay.CardNo;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@CARD_ID";
        para.Value = product.pay.CardId;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@COUPON_NO";
        para.Value = product.pay.CouponNo;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@COUPON_ID";
        para.Value = product.pay.CouponId;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@COUPON";
        para.Value = product.pay.Coupon;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@SALESMAN";
        para.Value = product.pay.SalesMan;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@BRANCH_CODE";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString();
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@INSERTED_BY";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["UserId"].ToString();
        paracol.Add(para);

        DataTable A = db.ExecuteSpForDT("SP_INSERT_SALES_DETAILS", paracol);
        BillNo = A.Rows[0][0].ToString();

        //Send SMS and Email to customer
        if (product.pay.CustMobile.Length == 10)
        {
            emailsender.SendMail(BillNo);
        }
        //End
        return BillNo;
    }

    [WebMethod(EnableSession = true)]
    public OfferReturn GenerateOffer(product product)
    {
        string BillNo = "";
        OfferReturn offer = new OfferReturn();

        DataTable dt_sales_details = new DataTable();
        dt_sales_details.Columns.Add("Id");
        dt_sales_details.Columns.Add("Barcode");
        dt_sales_details.Columns.Add("Amount");
        dt_sales_details.Columns.Add("Discount");
        dt_sales_details.Columns.Add("Qtr");
        dt_sales_details.AcceptChanges();

        List<pro> pr = product.pro;

        foreach (pro p in pr)
        {
            DataRow dr = dt_sales_details.NewRow();
            dr[0] = p.Id;
            dr[1] = p.Barcode;
            dr[2] = p.Amount;
            dr[3] = p.Discount;
            dr[4] = p.Qtr;


            dt_sales_details.Rows.Add(dr);
            dt_sales_details.AcceptChanges();
        }



        SqlParameterCollection paracol = new SqlCommand().Parameters;
        SqlParameter para;

        para = new SqlParameter();
        para.ParameterName = "@SALES_DETAILS";
        para.Value = dt_sales_details;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@BRANCH_CODE";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString();
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@INSERTED_BY";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["UserId"].ToString();
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@RETURN_NO";
        para.Value = product.pay.RefNo;
        paracol.Add(para);

        DataSet dt = db.ExecuteSP2DS("SP_ApplyOffer", paracol);
        //BillNo = A.Rows[0][0].ToString();

        List<item> list = new List<item>();
        for (int i = 0; i < dt.Tables[0].Rows.Count; i++)
        {
            list.Add(new item
            {
                _itemId = dt.Tables[0].Rows[i]["ItemId"].ToString()
                ,
                //_id = dt.Rows[i]["ProductCode"].ToString()
                //,
                _description = dt.Tables[0].Rows[i]["Description"].ToString()
                ,
                _barcode = dt.Tables[0].Rows[i]["BarcodeNo"].ToString()
                ,
                //_color = dt.Rows[i]["ColorName"].ToString()
                //,
                //_size = dt.Rows[i]["SizeName"].ToString()
                //,
                //_brand = dt.Rows[i]["BrandName"].ToString()
                //,
                //_design = dt.Rows[i]["DesignName"].ToString()
                //,
                //_category = dt.Rows[i]["CategoryName"].ToString()
                //,
                _unit = dt.Tables[0].Rows[i]["Unit"].ToString()
                ,
                _purchaseRate = dt.Tables[0].Rows[i]["PurchaseRate"].ToString()
                ,
                _saleRate = dt.Tables[0].Rows[i]["SaleRate"].ToString()
                ,
                _mrp = dt.Tables[0].Rows[i]["MRP"].ToString()
                ,
                _tax = dt.Tables[0].Rows[i]["Tax"].ToString()
                ,
                _qty = dt.Tables[0].Rows[i]["QTY"].ToString()
                ,
                _qtyType = dt.Tables[0].Rows[i]["QtyType"].ToString()
                ,
                _disc = dt.Tables[0].Rows[i]["DiscountPercent"].ToString()
            });
        }

        offer.list = list;
        try
        {
            if (dt.Tables.Count > 1)
            {
                offer.ReturnAmount = dt.Tables[1].Rows[0]["NetAmount"].ToString();
            }
        }
        catch { }

        return offer; //offer;
    }

    [WebMethod(EnableSession = true)]
    public Bill GetBill(string invoice)
    {
        try
        {
            Bill bill = new Bill();
            DataTable dt = db.getDataTable("SP_GET_CUSTOMER_BILL_INFO_FOR_RETURN '" + invoice + "'," + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString());
            if (dt.Rows.Count > 0)
            {
                bill.invoice = dt.Rows[0]["InvoiceNo"].ToString();
                bill.Date = dt.Rows[0]["SalesDate"].ToString();
                bill.cFname = dt.Rows[0]["FirstName"].ToString();
                bill.cMname = dt.Rows[0]["MiddleName"].ToString();
                bill.cLname = dt.Rows[0]["LastName"].ToString();
                bill.cAddress = dt.Rows[0]["StreetAddress"].ToString();
                bill.cMobile = dt.Rows[0]["CellPhone"].ToString();
                bill.cOcupation = dt.Rows[0]["Ocupation"].ToString();
                bill.dParcent = dt.Rows[0]["BillDiscPer"].ToString();
            }
            else
            {
                throw new Exception("Invoice No.: " + invoice + " not found! Invalid Invoice.");
            }

            return bill;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    [WebMethod(EnableSession = true)]
    public string GenerateReturnBill(productReturn product)
    {
        try
        {
            string BillNo = "";

            DataTable dt_sales_details = new DataTable();
            dt_sales_details.Columns.Add("Id");
            dt_sales_details.Columns.Add("Barcode");
            dt_sales_details.Columns.Add("Amount");
            dt_sales_details.Columns.Add("Discount");
            dt_sales_details.Columns.Add("Qtr");
            dt_sales_details.Columns.Add("Damage");
            dt_sales_details.AcceptChanges();

            List<proReturn> pr = product.pro;

            foreach (proReturn p in pr)
            {
                DataRow dr = dt_sales_details.NewRow();
                dr[0] = p.Id;
                dr[1] = p.Barcode;
                dr[2] = p.Amount;
                dr[3] = p.Discount;
                dr[4] = p.Qtr;
                dr[5] = p.Damage;

                dt_sales_details.Rows.Add(dr);
                dt_sales_details.AcceptChanges();
            }

            SqlParameterCollection paracol = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@SALES_DETAILS";
            para.Value = dt_sales_details;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@REF_NO";
            para.Value = product.pay.RefNo;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@NARRATION";
            para.Value = product.pay.Narration;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@BRANCH_CODE";
            para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@INSERTED_BY";
            para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["UserId"].ToString();
            paracol.Add(para);

            DataTable A = db.ExecuteSpForDT("SP_INSERT_SALES_RETURN_DETAILS", paracol);
            BillNo = A.Rows[0][0].ToString();
            return BillNo;
        }
        catch (Exception ex)
        {
            return ex.Message;
        }
    }

    [WebMethod(EnableSession = true)]
    public List<Customer> getCustomer(string name)
    {
        List<Customer> list = new List<Customer>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_SELECT_CUSTOMER '" + name + "','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Customer
            {
                customerId = dt.Rows[i]["CustomerID"].ToString()
                ,
                customerCode = dt.Rows[i]["CustomerCode"].ToString()
                ,
                customerName = dt.Rows[i]["CustomerName"].ToString()
                ,
                address = dt.Rows[i]["StreetAddress"].ToString()
                ,
                contactNo = dt.Rows[i]["CellPhone"].ToString()
                ,
                discount = dt.Rows[i]["Discount"].ToString()
                ,
                tax = dt.Rows[i]["Tax"].ToString()
                ,
                taxType = dt.Rows[i]["TaxType"].ToString()
            });
        }
        return list;

    }

    [WebMethod(EnableSession = true)]
    public List<SalesMan> getSalesMan(string name)
    {
        List<SalesMan> list = new List<SalesMan>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SALESMAN '" + name + "','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new SalesMan
            {
                SalesManName = dt.Rows[i]["SalesManName"].ToString()
            });
        }
        return list;

    }
    [WebMethod(EnableSession = true)]
    public string btnCreate_ShippingAddress_Click(string CourtesyTitle = "",string FirstName="",string MiddleName = "",string LastName = "",string StreetAddress ="",string City_Town = "",string State = "",string Postal = "",string Phone = "",string Cell = "", string Email = "",string txtOutType = "",string ddlBranch="")
    {
        try
        {
            SqlParameterCollection paracol = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@ID";
            para.Value = 0;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@CourtesyTitle";
            para.Value = CourtesyTitle.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@FirstName";
            para.Value = FirstName.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@MiddleName";
            para.Value = MiddleName.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@LastName";
            para.Value = LastName.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@StreetAddress";
            para.Value = StreetAddress.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@City_Town";
            para.Value = City_Town.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@State";
            para.Value = State.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@Postal";
            para.Value = Postal.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@Phone";
            para.Value = Phone.Trim();
            paracol.Add(para);


            para = new SqlParameter();
            para.ParameterName = "@Cell";
            para.Value = Cell.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@Email";
            para.Value = Email.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@txtOutType";
            if(txtOutType == "Local")
            {
                para.Value = 1;
            }
            else
            {
                para.Value = 2;
            }
            paracol.Add(para);


            para = new SqlParameter();
            para.ParameterName = "@ddlBranch";
            para.Value = ddlBranch;
            paracol.Add(para);

           
            DataTable dt = db.ExecuteSpForDT("Sp_Create_New_ShippingAddress", paracol);

            return dt.Rows[0][0].ToString();
        }
        catch (Exception ex)
        {
            return "";
        }
    }
    [WebMethod(EnableSession = true)]
    public List<ListItem> GetShipmentAddress(string ddlOutType="",string ddlBranch = "")
    {
        List<ListItem> Details = new List<ListItem>();
        DataTable dt = new DataTable();

        Details.Add(new ListItem { Text = "---- SAME ----", Value = "" });
        Details.Add(new ListItem { Text = "Create New", Value = "0" });


        SqlParameterCollection paracol = new SqlCommand().Parameters;
        SqlParameter para;

        para = new SqlParameter();
        para.ParameterName = "@PrimaryId";
        para.Value = ddlBranch;
        paracol.Add(para);
        

        para = new SqlParameter();
        para.ParameterName = "@PrimaryType";
        if (ddlOutType == "Local")
        {
            para.Value = 1;
        }
        else
        {
            para.Value = 2;
        }
        paracol.Add(para);

        dt = db.ExecuteSpForDT("Sp_Get_Shipping_Address", paracol);

        foreach(DataRow dr in dt.Rows)
        {
            Details.Add(new ListItem { Text = dr["ShippingAdd"].ToString(), Value = dr["ID"].ToString() });
        }

        return Details;

    }
    public class OfferReturn
    {
        public List<item> list { get; set; }
        public string ReturnAmount { get; set; }
    }
    public class item
    {
        public string _itemId { get; set; }
        public string _id { get; set; }
        public string _description { get; set; }
        public string _barcode { get; set; }
        public string _color { get; set; }
        public string _size { get; set; }
        public string _brand { get; set; }
        public string _category { get; set; }
        public string _design { get; set; }
        public string _unit { get; set; }
        public string _purchaseRate { get; set; }
        public string _saleRate { get; set; }
        public string _mrp { get; set; }
        public string _tax { get; set; }
        public string _qty { get; set; }
        public string _qtyType { get; set; }
        public string _disc { get; set; }
    }
    public class returnItem
    {
        public string _itemId { get; set; }
        public string _id { get; set; }
        public string _description { get; set; }
        public string _barcode { get; set; }
        public string _color { get; set; }
        public string _size { get; set; }
        public string _unit { get; set; }
        public string _disPercent { get; set; }
        public string _saleRate { get; set; }
        public string _mrp { get; set; }
        public string _tax { get; set; }
        public string _qty { get; set; }
        public string _qtyType { get; set; }
        public string _amount { get; set; }
    }

    public class pro
    {
        public string Id { get; set; }
        public string Barcode { get; set; }
        public string Amount { get; set; }
        public string Discount { get; set; }
        public string Qtr { get; set; }
    }
    public class pay
    {
        public string RefNo { get; set; }
        public string CustFName { get; set; }
        public string CustMName { get; set; }
        public string CustLName { get; set; }
        public string CustAddress { get; set; }
        public string CustMobile { get; set; }
        public string CustDOB { get; set; }
        public string Age { get; set; }
        public string Anniversary { get; set; }
        public string Gender { get; set; }
        public string Cash { get; set; }
        public string Card { get; set; }
        public string Points { get; set; }
        public string PointsValue { get; set; }
        public string Tax { get; set; }
        public string Discount { get; set; }
        public string SalesDate { get; set; }
        public string CardNo { get; set; }
        public string CardId { get; set; }
        public string CouponNo { get; set; }
        public string CouponId { get; set; }
        public string Coupon { get; set; }
        public string SalesMan { get; set; }
    }
    public class product
    {
        public pay pay { get; set; }
        public List<pro> pro { get; set; }
    }

    public class offer
    {
        public List<pro> pro { get; set; }
    }

    public class proReturn
    {
        public string Id { get; set; }
        public string Barcode { get; set; }
        public string Amount { get; set; }
        public string Discount { get; set; }
        public string Qtr { get; set; }
        public string Damage { get; set; }
    }
    public class payReturn
    {
        public string RefNo { get; set; }
        public string Narration { get; set; }
    }
    public class productReturn
    {
        public payReturn pay { get; set; }
        public List<proReturn> pro { get; set; }
    }

    public class Bill
    {
        public string invoice { get; set; }
        public string Date { get; set; }
        public string cFname { get; set; }
        public string cMname { get; set; }
        public string cLname { get; set; }
        public string cAddress { get; set; }
        public string cMobile { get; set; }
        public string cOcupation { get; set; }
        public string dParcent { get; set; }

    }


    //public class Customer
    //{
    //    public string customerId { get; set; }
    //    public string customerCode { get; set; }
    //    public string customerName { get; set; }
    //    public string address { get; set; }
    //    public string contactNo { get; set; }
    //    public string discount { get; set; }
    //    public string tax { get; set; }
    //    public string taxType { get; set; }
    //}
    [WebMethod(EnableSession = true)]
    public List<Customer> getCustomerPos(string name)
    {
        List<Customer> list = new List<Customer>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_SELECT_CUSTOMER_POS '" + name + "','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Customer
            {
                customerId = dt.Rows[i]["CustomerID"].ToString()
                ,
                customerCode = dt.Rows[i]["CustomerCode"].ToString()
                ,
                FName = dt.Rows[i]["FirstName"].ToString()
                ,
                MName = dt.Rows[i]["MiddleName"].ToString()
                ,
                LName = dt.Rows[i]["LastName"].ToString()
                ,
                customerName = dt.Rows[i]["CustomerName"].ToString()
                ,
                address = dt.Rows[i]["StreetAddress"].ToString()
                ,
                contactNo = dt.Rows[i]["CellPhone"].ToString()
                ,
                discount = dt.Rows[i]["Discount"].ToString()
                ,
                tax = dt.Rows[i]["Tax"].ToString()
                ,
                taxType = dt.Rows[i]["TaxType"].ToString()
                ,
                DOB = dt.Rows[i]["BirthDate"].ToString()
                ,
                Anniversary = dt.Rows[i]["AnniversaryDate"].ToString()
                ,
                Male = dt.Rows[i]["Male"].ToString()
                 ,
                Female = dt.Rows[i]["Female"].ToString()
                ,
                Points = dt.Rows[i]["Points"].ToString()
                 ,
                Valuation = dt.Rows[i]["Valuation"].ToString()
            });
        }
        return list;

    }
    public class Customer
    {
        public string customerId { get; set; }
        public string customerCode { get; set; }
        public string FName { get; set; }
        public string MName { get; set; }
        public string LName { get; set; }
        public string customerName { get; set; }
        public string address { get; set; }
        public string contactNo { get; set; }
        public string discount { get; set; }
        public string tax { get; set; }
        public string taxType { get; set; }
        public string DOB { get; set; }
        public string Anniversary { get; set; }
        public string Male { get; set; }
        public string Female { get; set; }
        public string Points { get; set; }
        public string Valuation { get; set; }
    }

    public class SalesMan
    {
        public string SalesManName { get; set; }
    }
}
