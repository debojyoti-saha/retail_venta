﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Retail.DAL;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI;

/// <summary>
/// Summary description for GlobalClass
/// </summary>
public class GlobalClass
{
    DBClass db = new DBClass();
	public GlobalClass()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public void FillDropDown(DropDownList ddl, string procedure, string DataTextField, string DataValueField, string FirstText)
    {
        DataTable dt = db.getDataTable(procedure);
        ddl.DataSource = dt;
        ddl.DataTextField = DataTextField;
        ddl.DataValueField = DataValueField;
        ddl.DataBind();

        ddl.Items.Insert(0, new ListItem(FirstText, "0"));
    }

    public void FillCheckBox(CheckBoxList chk, string procedure, string DataTextField, string DataValueField)
    {
        DataTable dc = db.getDataTable(procedure);
        chk.DataSource = dc;
        chk.DataTextField = DataTextField;
        chk.DataValueField = DataValueField;
        chk.DataBind();

        //ddl.Items.Insert(0, new ListItem(FirstText, "0"));
    }


    public void FillRadioButtonList(RadioButtonList rbl, string procedure, string DataTextField, string DataValueField)
    {
        DataTable dr = db.getDataTable(procedure);
        rbl.DataSource = dr;
        rbl.DataTextField = DataTextField;
        rbl.DataValueField = DataValueField;
        
        rbl.DataBind();

        //rbl.Items.Insert(RadioButtonList Refrence);
    }

    public void FillTEXTBOX(TextBox txt,string PROCEDURE)
    {
        DataTable dt = db.getDataTable(PROCEDURE);
        txt.Text = dt.Rows[0][0].ToString();
        

        

        //rbl.Items.Insert(RadioButtonList Refrence);
    }

    public void FillCHECKBOX(CheckBox CHK, string PROCEDURE)
    {
        DataTable dt = db.getDataTable(PROCEDURE);
        CHK.Checked = dt.Rows[0][1].Equals(1);




        //rbl.Items.Insert(RadioButtonList Refrence);
    }
    public void ClearInputs(ControlCollection ctrls)
    {
        foreach (Control ctrl in ctrls)
        {
            if (ctrl is TextBox)
                ((TextBox)ctrl).Text = string.Empty;
            else if (ctrl is DropDownList)
                ((DropDownList)ctrl).ClearSelection();
            else if (ctrl is CheckBox)
                ((CheckBox)ctrl).Checked = false;

            ClearInputs(ctrl.Controls);
        }
    }
}