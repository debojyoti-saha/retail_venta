﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;

/// <summary>
/// Summary description for Validator
/// </summary>
/// 
namespace Retail.DAL
{
    public class Validator
    {
        public Validator()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public void SetMessage(Page page ,ValidationSummary validationsummary,CustomValidator validator, string groupname, string message, string mode)
        {
            validator.ErrorMessage = message;
            string color="";
            if (mode == "success")
            {
                validationsummary.CssClass = "successMessage";
                //color = "#29A329";
            }
            else if (mode == "error")
            {
                validationsummary.CssClass = "errorMessage";
                //color = "#FF0000";
            }
            else if (mode == "info")
            {
                validationsummary.CssClass = "infoMessage";
                //color = "#3385D6";
            }
            else if (mode == "warning")
            {
                validationsummary.CssClass = "warningMessage";
                //color = "#E68A00";
            }

            if (groupname != "")
            {
                validator.ValidationGroup = groupname;
            }
            validator.IsValid = false;
            validationsummary.ForeColor = System.Drawing.ColorTranslator.FromHtml(color);
            page.Validators.Add(validator);
        }
    }
}