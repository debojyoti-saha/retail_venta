﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using Retail.DAL;

/// <summary>
/// Summary description for User
/// </summary>
/// 
namespace Retail.BL.Master
{
    public class User
    {
        DBClass db = new DBClass();
        public User()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public void InsertUpdateUser(string _username, string _userfullname, string _usertype, string _branchid, string _phonenumber, string _mobilenumber, string _streetname, string _citytown, string _state, Boolean _status, string _parameter,byte[] Image)
        {
            try
            {
                SqlParameterCollection paracoll = new SqlCommand().Parameters;
                SqlParameter para;

                para = new SqlParameter();
                para.ParameterName = "@USER_NAME";
                para.Value = _username;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@FULL_NAME";
                para.Value = _userfullname;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@USER_TYPE";
                para.Value = _usertype;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@USER_BRANCH";
                para.Value = _branchid;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@PHONE_NUMBER";
                para.Value = _phonenumber;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@MOBILE_NUMBER";
                para.Value = _mobilenumber;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@STREET_NAME";
                para.Value = _streetname;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@CITY_TOWN";
                para.Value = _citytown;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@STATE";
                para.Value = _state;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@STATUS";
                para.Value = _status;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@PARAMETER";
                para.Value = _parameter;
                paracoll.Add(para);

                para = new SqlParameter();
                para.ParameterName = "@PICTURE";
                para.Value = Image;
                paracoll.Add(para);

                DataTable dt_info = db.ExecuteSpForDT("SP_CREATE_UPDATE_NEW_USER", paracoll);
            }
            catch(Exception ex)
            {
                throw ex;
            }

        }
    }
}