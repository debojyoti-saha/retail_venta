﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Text;
using System.Net;
using System.IO;
using Retail.DAL;

/// <summary>
/// Summary description for SendSMS
/// </summary>
public class SendSMS
{
    Cryptography cr = new Cryptography();
    StringBuilder sbPostData = new StringBuilder();
    public SendSMS()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public void send(string mobile, string text)
    {
        try
        {
            if (Convert.ToInt32(getBalence()) > 0)
            {
                //Your authentication user
                string user = ConfigurationManager.AppSettings["user"].ToString();
                //Your authentication pass
                string pass = ConfigurationManager.AppSettings["pass"].ToString();
                //Multiple mobiles numbers seperated by comma
                string mobileNumber = mobile;
                //Sender ID,While using route4 sender id should be 6 characters long.
                string senderId = ConfigurationManager.AppSettings["senderId"].ToString();
                //Your message to send, Add URL endcoding here.
                string priority = ConfigurationManager.AppSettings["priority"].ToString();
                //string message = HttpUtility.UrlEncode("Test message");
                string stype = ConfigurationManager.AppSettings["stype"].ToString();
                //string message = HttpUtility.UrlEncode("Test message");


                //Prepare you post parameters
                sbPostData.AppendFormat("user={0}", user);
                sbPostData.AppendFormat("&pass={0}", pass);
                sbPostData.AppendFormat("&sender={0}", senderId);
                sbPostData.AppendFormat("&phone={0}", mobileNumber);
                sbPostData.AppendFormat("&text={0}", text);
                sbPostData.AppendFormat("&priority={0}", priority);
                sbPostData.AppendFormat("&stype={0}", stype);
            }
            else
            {
                return;
            }
        }
        catch
        {
            return;
        }


        try
        {
            //Call Send SMS API
            string sendSMSUri = "http://" + ConfigurationManager.AppSettings["gateway"].ToString() + "/api/sendmsg.php";
            //Create HTTPWebrequest
            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
            //Prepare and Add URL Encoded data
            UTF8Encoding encoding = new UTF8Encoding();
            byte[] data = encoding.GetBytes(sbPostData.ToString());

            if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsProxy"].ToString()))
            {
                WebProxy myproxy = new WebProxy(ConfigurationManager.AppSettings["Proxy_Host"].ToString(), Convert.ToInt32(ConfigurationManager.AppSettings["Proxy_Port"].ToString()));
                myproxy.BypassProxyOnLocal = Convert.ToBoolean(ConfigurationManager.AppSettings["Proxy_Bypass"]);
                httpWReq.Proxy = myproxy;
            }


            //Specify post method
            httpWReq.Timeout = 30000;
            httpWReq.Method = "POST";
            httpWReq.ContentType = "application/x-www-form-urlencoded";
            httpWReq.ContentLength = data.Length;
            using (Stream stream = httpWReq.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            //Get the response
            HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            string responseString = reader.ReadToEnd();

            //Close the response
            reader.Close();
            response.Close();
        }
        catch (Exception ex)
        {
            cr.SendMail("support@tradesights.com", "", "RUPS: Error on SMS Send Mobile-" + mobile, "Message:<br />" + ex.Message + "<br />StackTrace:<br />" + ex.StackTrace.ToString());
        }
    }

    public string getBalence()
    {
        //Your authentication key
        string user = ConfigurationManager.AppSettings["user"].ToString();
        //Multiple mobiles numbers seperated by comma

        string pass = ConfigurationManager.AppSettings["pass"].ToString();
        //Your message to send, Add URL endcoding here.
        //string message = HttpUtility.UrlEncode("Test message");

        //Prepare you post parameters
        StringBuilder sbPostData = new StringBuilder();
        sbPostData.AppendFormat("user={0}", user);
        sbPostData.AppendFormat("&pass={0}", pass);

        try
        {
            //Call Send SMS API
            string sendSMSUri = "http://" + ConfigurationManager.AppSettings["gateway"].ToString() + "/api/checkbalance.php";
            //Create HTTPWebrequest
            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create(sendSMSUri);
            //Prepare and Add URL Encoded data
            UTF8Encoding encoding = new UTF8Encoding();
            byte[] data = encoding.GetBytes(sbPostData.ToString());

            if (Convert.ToBoolean(ConfigurationManager.AppSettings["IsProxy"].ToString()))
            {
                WebProxy myproxy = new WebProxy(ConfigurationManager.AppSettings["Proxy_Host"].ToString(), Convert.ToInt32(ConfigurationManager.AppSettings["Proxy_Port"].ToString()));
                myproxy.BypassProxyOnLocal = Convert.ToBoolean(ConfigurationManager.AppSettings["Proxy_Bypass"]);
                httpWReq.Proxy = myproxy;
            }


            //pecify post method
            httpWReq.Method = "POST";
            httpWReq.ContentType = "application/x-www-form-urlencoded";
            httpWReq.ContentLength = data.Length;
            using (Stream stream = httpWReq.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            //Get the response
            HttpWebResponse response = (HttpWebResponse)httpWReq.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream());
            string responseString = reader.ReadToEnd();

            //Close the response
            reader.Close();
            response.Close();

            //CustomValidator cval = new CustomValidator();
            //cval.ErrorMessage = mobileNumber+", SMS send successfully!!";
            //cval.IsValid = false;
            //Page.Validators.Add(cval);
            return responseString;
        }
        catch (SystemException ex)
        {
            return ex.Message;
        }

    }
}