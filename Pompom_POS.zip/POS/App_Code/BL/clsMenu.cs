﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Retail.DAL;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;

/// <summary>
/// Summary description for Menu
/// </summary>
/// 
namespace Retail.BL
{
public class clsMenu
{
  
        DataTable dt = new DataTable();
        DBClass db = new DBClass();
        DataSet DbMenu;
        DataRelation relation;
        string ErrorMsg;
        public clsMenu()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public string getModuleID(string strModuleName)
        {
            SqlParameterCollection paracoll = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@Module_Name";
            para.Value = strModuleName;
            paracoll.Add(para);

            try
            {
                dt = db.ExecuteSpForDT("Get_ModuleID", paracoll);
                return dt.Rows[0]["MOD_ID"].ToString();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public void getMenuForModule(string moduleID)
        {
            SqlParameterCollection paracoll = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@Module_Id";
            para.Value = moduleID;
            paracoll.Add(para);

            try
            {
                dt = db.ExecuteSpForDT("Get_Menu_For_Module", paracoll);
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public string GenerateXmlFormat(string userId)
        {
            SqlParameterCollection paracoll = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@User_Id";
            para.Value = userId;
            paracoll.Add(para);

            try
            {
                DbMenu = new DataSet();
                DbMenu = db.ExecuteSP2DS("SP_GET_MENU", paracoll);
                DbMenu.DataSetName = "Menus";
                DbMenu.Tables[0].TableName = "Menu";
                //create Relation Parent and Child
                relation = new DataRelation("ParentChild", DbMenu.Tables["Menu"].Columns["MenuID"], DbMenu.Tables["Menu"].Columns["ParentID"], true);
                relation.Nested = true;
                DbMenu.Relations.Add(relation);
                return DbMenu.GetXml();
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public string ExecuteXSLTransformation(string userId)
        {
            string HtmlTags, XsltPath;
            MemoryStream DataStream = default(MemoryStream);
            StreamReader streamReader = default(StreamReader);
            try
            {
                //Path of XSLT file
                XsltPath = HttpContext.Current.Server.MapPath("~/Xml/XsltTransformer.xslt");
                //Encode all Xml format string to bytes
                byte[] bytes = Encoding.ASCII.GetBytes(GenerateXmlFormat(userId));
                DataStream = new MemoryStream(bytes);
                //Create Xmlreader from memory stream
                XmlReader reader = XmlReader.Create(DataStream);
                // Load the XML 
                XPathDocument document = new XPathDocument(reader);
                XslCompiledTransform XsltFormat = new XslCompiledTransform();
                // Load the style sheet.
                XsltFormat.Load(XsltPath);
                DataStream = new MemoryStream();
                XmlTextWriter writer = new XmlTextWriter(DataStream, Encoding.ASCII);
                //Apply transformation from xml format to html format and save it in xmltextwriter
                XsltFormat.Transform(document, writer);
                streamReader = new StreamReader(DataStream);
                DataStream.Position = 0;
                HtmlTags = streamReader.ReadToEnd();
                return HtmlTags;
            }
            catch (Exception ex)
            {
                ErrorMsg = ex.Message;
                return ErrorMsg;
            }
            finally
            {
                //Release the resources 
                streamReader.Close();
                DataStream.Close();
            }
        }
        public bool checkModulePermission(string userId, string moduleId)
        {
            SqlParameterCollection paracoll = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@UserId";
            para.Value = Convert.ToInt64(userId);
            paracoll.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@Module_Id";
            para.Value = Convert.ToInt64(moduleId);
            paracoll.Add(para);

            try
            {
                dt = db.ExecuteSpForDT("Sp_Select_User_Permission_Details", paracoll);
                return Convert.ToBoolean(dt.Rows[0]["isMenuAvailable"].ToString());

            }
            catch (Exception ex)
            {
                throw;
            }
        }
 
}
}