﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.ComponentModel;
using Retail.DAL;

/// <summary>
/// Summary description for EmailSender
/// </summary>
/// 

public class EmailSender
{
    DBClass db = new DBClass();
    Cryptography cr = new Cryptography();

    public EmailSender()
    {
        //
        // TODO: Add constructor logic here
        //

    }

    //public void Start()
    //{
    //    if (worker.IsBusy != true)
    //    {
    //        // Code that runs on application startup

    //        worker.DoWork += new DoWorkEventHandler(SendMail);
    //        worker.WorkerReportsProgress = false;
    //        worker.WorkerSupportsCancellation = true;
    //        worker.RunWorkerCompleted +=
    //               new RunWorkerCompletedEventHandler(WorkerCompleted);
    //        // Calling the DoWork Method Asynchronously
    //        worker.RunWorkerAsync();
    //        WorkerStatus = true;
    //        //cr.SendMail("support@esskaytech.com", "", "Linde: Email Worker start", "Email Worker Start at "+DateTime.Now.ToString());
    //        worker.Dispose();
    //    }
    //}

    public void SendMail(string InvoiceNo)
    {
        SendSMS SMS = new SendSMS();


        try
        {
            DataTable dt_SMS_List = new DataTable();
            dt_SMS_List = db.getDataTable("SP_SEND_SMS_ON_PURCHASE '" + InvoiceNo + "'");
            int SMScount = dt_SMS_List.Rows.Count;
            if (SMScount > 0)
            {
                for (int i = 0; i < SMScount; i++)
                {
                    string _mobile = dt_SMS_List.Rows[i]["MobileNo"].ToString();
                    string _text = dt_SMS_List.Rows[i]["Text"].ToString();
                    //send SMS
                    SMS.send(_mobile, _text);
                }
                
            }
        }
        catch (Exception ex)
        {
            //cr.SendMail("support@esskaytech.com", "", "Linde: Error on SMS Send", "Message:<br />" + ex.Message + "<br />StackTrace:<br />" + ex.StackTrace.ToString());
            //time = 300000;
        }
    }

    //private static void WorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
    //{
    //    // log when the worker is completed.
    //    BackgroundWorker worker = sender as BackgroundWorker;
    //    if (worker != null)
    //    {
    //        // sleep for 20 secs and again call DoWork to get FxRates..we can increase the time to sleep and make it configurable to the needs
    //        System.Threading.Thread.Sleep(time);
    //        worker.RunWorkerAsync();
    //    }

    //    if ((e.Cancelled == true))
    //    {
    //        worker.Dispose();
    //    }

    //}
}