﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Retail.DAL;

/// <summary>
/// Summary description for Permission
/// </summary>
/// 

public class Permission
{
    DBClass db = new DBClass();
	public Permission()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public bool UserPagePermission(string PageName)
    {
        string result = db.returnValue("SP_PAGE_PERMISSION '" + PageName + "','" + HttpContext.Current.User.Identity.Name + "'");
        return Convert.ToBoolean(Int32.Parse(result));
    }
}