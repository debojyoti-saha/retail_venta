﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.Security;
using Retail.DAL;
using System.Data.SqlClient;


public partial class Accounts_Expenses : System.Web.UI.Page
{
    DBClass db = new DBClass();
    Validator val = new Validator();
    GlobalClass gc = new GlobalClass();
    CustomValidator cval = new CustomValidator();
    public decimal Amounts=0;
    protected void Page_Load(object sender, EventArgs e)
    {
        //for(int i=0; i>5; i++){
        //    ((Label)gvExpensesDetails.FindControl("lblPerticulars")).Text = i.ToString() + "s";
        //    ((TextBox)gvExpensesDetails.FindControl("txtCredit")).Text = i.ToString() + "s";
        //}
        //gvExpensesDetails.DataBind();
        ScriptManager.RegisterStartupScript(this, this.GetType(), "Autofill", "javascript:autofill();", true);
        lblCurrentDate.Text = System.DateTime.Now.ToString("dd/MM/yyyy");
        lblCurrentDay.Text = DateTime.Now.DayOfWeek.ToString();
        if (!IsPostBack)
        {
            FillMainGrid();
        }

    }
    protected void gvExpensesDetails_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = gvExpensesDetails.SelectedRow;
        Session["Temp_Value"] = gvExpensesDetails.SelectedIndex;
        lblAc.Text = ((Label)row.FindControl("lblAccount")).Text;
        txtDescription.Text = ((Label)row.FindControl("lblPerticulars")).Text;
        txtAmount.Text = ((Label)row.FindControl("lblCredit")).Text;
        lblAcCode.Text = ((Label)row.FindControl("lblAccountCode")).Text;
        ddlType.SelectedValue = ((Label)row.FindControl("lblType")).Text;
        txtCheque.Text = ((Label)row.FindControl("lblCheque")).Text;
        txtChequeDate.Text = ((Label)row.FindControl("lblChaqueDate")).Text;
        txtBank.Text = ((Label)row.FindControl("lblBank")).Text;

        ModalDetailsPopup.Show();
        Session["_work"] = "edit";
        ModalExpensesEntry.Show();
    }
    protected void btnEntry_Click(object sender, EventArgs e)
    {
        
        lblAc.Text = txtAccounts.Text.Trim();
        lblAcCode.Text = txtAccountsCode.Text.Trim();
        txtDescription.Text = "";
        txtAmount.Text = "";
        Session["_work"] = "add";    
        ModalDetailsPopup.Show();
        ModalExpensesEntry.Show();
    }
    protected void btnOk_Click(object sender, EventArgs e)
    {

        if (Session["_work"].ToString() == "add")
        {
            
            DataTable dt = new DataTable();
            dt.Columns.Add("Acc");
            dt.Columns.Add("per");
            dt.Columns.Add("crd");
            dt.Columns.Add("AccCode");
            dt.Columns.Add("type");
            dt.Columns.Add("chq");
            dt.Columns.Add("chqdate");
            dt.Columns.Add("bank");
            DataRow row;

            for (int i = 0; i < gvExpensesDetails.Rows.Count; i++)
            {
                
                row = dt.NewRow();
                row[0] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblAccount")).Text;
                row[1] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblPerticulars")).Text;
                row[2] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblCredit")).Text;
                row[3] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblAccountCode")).Text;
                row[4] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblType")).Text;
                row[5] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblCheque")).Text;
                row[6] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblChaqueDate")).Text;
                row[7] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblbank")).Text;
                dt.Rows.Add(row);
                dt.AcceptChanges();
            }

            row = dt.NewRow();
            row[0] = lblAc.Text;
            row[1] = txtDescription.Text.Trim();
            row[2] = txtAmount.Text.Trim();
            row[3] = lblAcCode.Text.Trim();
            row[4] = ddlType.SelectedValue;
            row[5] = txtCheque.Text.Trim();
            row[6] = txtChequeDate.Text.Trim();
            row[7] = txtBank.Text.Trim();
            dt.Rows.Add(row);
            dt.AcceptChanges();

            gvExpensesDetails.DataSource = dt;
            gvExpensesDetails.DataBind();


            txtAccounts.Text = "";
        }
        else if (Session["_work"].ToString() == "edit")
        {
            int row = (int)Session["Temp_Value"];
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblAccount")).Text=lblAc.Text;
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblPerticulars")).Text = txtDescription.Text.Trim();
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblCredit")).Text = txtAmount.Text.Trim();
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblAccountCode")).Text = lblAcCode.Text.Trim();
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblType")).Text = ddlType.SelectedValue;
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblCheque")).Text = txtCheque.Text.Trim();
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblChaqueDate")).Text = txtChequeDate.Text.Trim();
           ((Label)gvExpensesDetails.Rows[row].FindControl("lblBank")).Text = txtBank.Text.Trim();
        }
        ModalExpensesEntry.Show();
    }
    protected void btnExpensesEntry_Click(object sender, EventArgs e)
    {
        ModalExpensesEntry.Show();
        txtRefNo.Text = "";
        txtNarration.Text = "";
        lblInvoiceNo.Text = "";
        BlankGrid();
    }
    protected void gvExpensesDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            decimal amount = Convert.ToDecimal(((Label)e.Row.FindControl("lblCredit")).Text);
            Amounts += amount;
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            ((Label)e.Row.FindControl("lblTotal")).Text = Amounts.ToString();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            if (gvExpensesDetails.Rows.Count <= 0)
            {
                throw new Exception("Fill atlast one a/c details!");
            }
            DataTable dt = new DataTable();

            dt.Columns.Add("ACC_CODE");
            dt.Columns.Add("DESCR");
            dt.Columns.Add("TYPE");
            dt.Columns.Add("BANK");
            dt.Columns.Add("CHEQUE");
            dt.Columns.Add("CHQDATE");
            dt.Columns.Add("AMOUNT");


            DataRow row;

            for (int i = 0; i < gvExpensesDetails.Rows.Count; i++)
            {

                row = dt.NewRow();
                row["DESCR"] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblPerticulars")).Text;
                row["AMOUNT"] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblCredit")).Text;
                row["ACC_CODE"] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblAccountCode")).Text;
                row["TYPE"] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblType")).Text;
                row["CHEQUE"] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblCheque")).Text;
                row["CHQDATE"] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblChaqueDate")).Text;
                row["BANK"] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblbank")).Text;
                dt.Rows.Add(row);
                dt.AcceptChanges();
            }

            

            SqlParameterCollection paracol = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@INVOICE_NO";
            para.Value = lblInvoiceNo.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@REF_NO";
            para.Value = txtRefNo.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@EXPENSES_DATA";
            para.Value = dt;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@NARRATION";
            para.Value = txtNarration.Text;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@USER";
            para.Value = Request.Cookies["UserCookies"]["UserId"].ToString();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@BRANCH";
            para.Value = Request.Cookies["UserCookies"]["Branch"].ToString();
            paracol.Add(para);

            string message = db.ExecuteSpForInsert("SP_INSERT_UPDATE_OTHER_EXPENSES", paracol);
            val.SetMessage(this.Page, ValidationSummary, cval, "", "Expenses generate successfully!", "success");
            
            gc.ClearInputs(this.Controls);
            BlankGrid();
            FillMainGrid();
        }
        catch (Exception ex)
        {
            val.SetMessage(this, ValidationSummary, cval, "", ex.Message, "error");
        }
        finally
        {
            ModalExpensesEntry.Show();
        }
    }
    protected void gvExpensesDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Acc");
            dt.Columns.Add("per");
            dt.Columns.Add("crd");
            dt.Columns.Add("AccCode");
            dt.Columns.Add("type");
            dt.Columns.Add("chq");
            dt.Columns.Add("chqdate");
            dt.Columns.Add("bank");
            DataRow row;

            for (int i = 0; i < gvExpensesDetails.Rows.Count; i++)
            {

                row = dt.NewRow();
                row[0] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblAccount")).Text;
                row[1] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblPerticulars")).Text;
                row[2] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblCredit")).Text;
                row[3] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblAccountCode")).Text;
                row[4] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblType")).Text;
                row[5] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblCheque")).Text;
                row[6] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblChaqueDate")).Text;
                row[7] = ((Label)gvExpensesDetails.Rows[i].FindControl("lblbank")).Text;
                dt.Rows.Add(row);
                dt.AcceptChanges();
            }

            int rownumber = e.RowIndex;
            dt.Rows[rownumber].Delete();
            dt.AcceptChanges();

            gvExpensesDetails.DataSource = dt;
            gvExpensesDetails.DataBind();
        }
        catch (Exception ex)
        {
            val.SetMessage(this, ValidationSummary, cval, "", ex.Message, "error");
        }
        finally
        {
            ModalExpensesEntry.Show();
        }
    }
    protected void BlankGrid()
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("AccCode");
        dt.Columns.Add("Acc");
        dt.Columns.Add("per");
        dt.Columns.Add("crd");
        dt.Columns.Add("type");
        dt.Columns.Add("chq");
        dt.Columns.Add("chqdate");
        dt.Columns.Add("bank");

        gvExpensesDetails.DataSource = dt;
        gvExpensesDetails.DataBind();
    }
    protected void FillMainGrid()
    {
        DataTable dt = db.getDataTable("SP_SELECT_EXPENSES '','','" + Request.Cookies["UserCookies"]["Branch"].ToString() + "'");
        gvExpensesMainDetails.DataSource = dt;
        gvExpensesMainDetails.DataBind();

        Session["Temp_Value"] = dt;
    }
    protected void gvExpensesMainDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "PView" || e.CommandName == "PEdit")
        {
            DataTable dt = db.getDataTable("SP_GET_EXPENSES '" + e.CommandArgument.ToString() + "'");
            gvExpensesDetails.DataSource = dt;
            gvExpensesDetails.DataBind();

            txtRefNo.Text = dt.Rows[0]["RefNo"].ToString();
            txtNarration.Text = dt.Rows[0]["Narration"].ToString();
            lblInvoiceNo.Text = e.CommandArgument.ToString();
            lblCurrentDate.Text = dt.Rows[0]["InvoiceDate"].ToString();
            lblCurrentDay.Text = dt.Rows[0]["InvoiceWeek"].ToString();

            ModalExpensesEntry.Show();

            if (e.CommandName == "PView")
            {
                btnSubmit.Visible = false;
            }
            else if (e.CommandName == "PEdit")
            {
                btnSubmit.Visible = true;
            }
        }

        else if (e.CommandName == "PDelete")
        {
            string MESSAGE = db.returnValue("SP_DELETE_EXPENSES '"+e.CommandArgument.ToString()+"'");
            FillMainGrid();
            val.SetMessage(this, ValidationSummary_main, cval, "Main", "Invoice deteted successfully!", "success");
        }

        else if (e.CommandName == "PPrint")
        {


            Cryptography cr = new Cryptography();
            string rid = cr.Encrypt_SHA("7", true);
            string para6 = cr.Encrypt_SHA(e.CommandArgument.ToString(), true);
            ScriptManager.RegisterStartupScript(this, this.GetType(), "print", "javascript:MyPopUpWin('../Report/ReportViewer.aspx?rid=" + rid + "&p1=" + para6 + "','800px', '800px');", true);
         



        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        DataTable dt = db.getDataTable("SP_SELECT_EXPENSES '"+ddlSearchType.SelectedValue+"','"+txtSearchText.Text.Trim()+"','"+Request.Cookies["UserCookies"]["Branch"].ToString()+"'");
        gvExpensesMainDetails.DataSource = dt;
        gvExpensesMainDetails.DataBind();

        Session["Temp_Value"] = dt;
    }
    protected void gvExpensesMainDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvExpensesMainDetails.PageIndex = e.NewPageIndex;
        gvExpensesMainDetails.DataSource = Session["Temp_Value"];
        gvExpensesMainDetails.DataBind();
    }
}