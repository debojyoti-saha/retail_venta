﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;
using System.Web.Security;
using System.Configuration;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text;


public partial class Accounts_ChangePassword : System.Web.UI.Page
{

    string sUserName;
    string sLocationCode;

    bool checkUserName;
    SqlTransaction transaction;
    string userid = "";
    DBClass db = new DBClass();
    Cryptography crypto = new Cryptography();

    CustomValidator validator = new CustomValidator();
    Validator val = new Validator();


    protected void Page_Load(object sender, EventArgs e)
    {
        sUserName = HttpContext.Current.User.Identity.Name;
     
        if (!Page.IsPostBack)
        {

        }
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        UpdatePassword();
    }

    public void UpdatePassword()
    {
        if (txtPassword.Text.Trim() == txtNewPassword.Text.Trim())
        {
            validator = new CustomValidator();
            validator.ErrorMessage = "Password cannot be same as the old password";
            validator.IsValid = false;
            Page.Validators.Add(validator);
        }
        else if (txtNewPassword.Text.Trim() != txtNewPassword2.Text.Trim())
        {
            validator = new CustomValidator();
            validator.ErrorMessage = "Password does not match";
            validator.IsValid = false;
            Page.Validators.Add(validator);

        }

        else
        {
            try
            {

                DataTable dt = db.getDataTable("spUpdatePassword '" + sUserName + "','" + crypto.Encrypt_SHA(txtPassword.Text.Trim(), true) + "','" + crypto.Encrypt_SHA(txtNewPassword.Text.Trim(), true) + "'");
                val.SetMessage(this, ValidationSummary1, validator, "", "New Password Save Successfully", "success");
            }
            catch (Exception ex)
            {
                val.SetMessage(this, ValidationSummary1, validator, "", ex.Message, "error");
            }
        }
    }
}