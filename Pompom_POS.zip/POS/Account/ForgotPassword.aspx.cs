﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;
using System.IO;

public partial class Account_ForgotPassword : System.Web.UI.Page
{
    CustomValidator val;
    DBClass db = new DBClass();
    Cryptography crypto = new Cryptography();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {

        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (UserName.Text.ToString() == "")
        {
            val = new CustomValidator();
            val.ErrorMessage = "Please enter Email";
            val.Display = ValidatorDisplay.None;
            val.IsValid = false;
            //val.ValidationGroup = "LoginUserValidationGroup";
            Page.Validators.Add(val);
        }

        if (Captcha.Text.ToString() != Session["captcha"].ToString())
        {
            val = new CustomValidator();
            val.ErrorMessage = "Invalid captcha entered";
            val.Display = ValidatorDisplay.None;
            val.IsValid = false;
            //val.ValidationGroup = "LoginUserValidationGroup";
            Page.Validators.Add(val);
        }

        DataTable dt_info = db.getDataTable("SP_USER_INFO '"+ UserName.Text.ToString()+"'");
        if (dt_info.Rows.Count > 0)
        {
            string html = File.ReadAllText(Server.MapPath("~/Files/PasswordMail.txt"));
            html = html.Replace("#userid", dt_info.Rows[0]["Username"].ToString()).Replace("#password", crypto.Decrypt_SHA(dt_info.Rows[0]["UPassword"].ToString(), true));
            crypto.SendMail(UserName.Text.ToString(), "", "Magic Retail Password Details", html);
            Response.RedirectPermanent("~/Account/Login.aspx?Message=Your password is successfully send on your mail address");
        }
        else
        {
            val = new CustomValidator();
            val.ErrorMessage = "Invalid Email address!";
            val.Display = ValidatorDisplay.None;
            val.IsValid = false;
            //val.ValidationGroup = "LoginUserValidationGroup";
            Page.Validators.Add(val);
        }


        Captcha.Text = "";
    }
    protected void imgbtnRefreshCaptcha_Click(object sender, ImageClickEventArgs e)
    {
        Random rnd = new Random();
        imgCaptcha.ImageUrl = "~/Handler.ashx?query=" + rnd.Next(1, 100000);
    }

}