﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using Retail.DAL;

/// <summary>
/// Summary description for Service
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService
{

    DBClass db = new DBClass();

    public Service()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod(EnableSession = true)]
    public string GetBranchOnOrderNo(string OrderNo)
    {
        string Message = db.returnValue("SELECT CreateBranch FROM tblMeterialRequestMain where InvoiceNo='"+OrderNo+"'");
        return Message;
    }


    [WebMethod(EnableSession = true)]
    public List<Color> getColor(string name, string code)
    {
        List<Color> list = new List<Color>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE 'color','" + code + "','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Color { _id = dt.Rows[i]["ColorCode"].ToString(), _colorName = dt.Rows[i]["ColorName"].ToString(), _colorShortName = dt.Rows[i]["ColorReference"].ToString() });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<Size> getSize(string name, string code)
    {
        List<Size> list = new List<Size>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE 'size','" + code + "','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Size { _id = dt.Rows[i]["SizeCode"].ToString(), _sizeName = dt.Rows[i]["Description"].ToString(), _sizeShortName = dt.Rows[i]["SizeRefrence"].ToString() });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<Rack> getRack(string name)
    {
        List<Rack> list = new List<Rack>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE 'rack','','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Rack { _id = dt.Rows[i]["Rack_id"].ToString(), _rackName = dt.Rows[i]["Rack_Name"].ToString(), _rackShortName = dt.Rows[i]["Rack_Position"].ToString() });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<Supplier> getsSupplier(string name)
    {
        List<Supplier> list = new List<Supplier>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE 'supplier','','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Supplier { _id = dt.Rows[i]["SupplierCode"].ToString(), _supplerName = dt.Rows[i]["CompanyName"].ToString() });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<item> getItem(string name, string type)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE '"+type+"','','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _itemId = dt.Rows[i]["ItemId"].ToString()
                ,
                //_id = dt.Rows[i]["ProductCode"].ToString()
                //,
                //_brand = dt.Rows[i]["BrandName"].ToString()
                //,
                //_category = dt.Rows[i]["CategoryName"].ToString()
                //,
                _design = dt.Rows[i]["Design"].ToString()
                ,
                _description = dt.Rows[i]["Description"].ToString()
                //,
                //_color = dt.Rows[i]["ColorName"].ToString()
                //,
                //_size = dt.Rows[i]["SizeName"].ToString()
                ,
                _purchaseRate = dt.Rows[i]["PurchaseRate"].ToString()
                ,
                _purchaseTax = dt.Rows[i]["PurchaseTaxPercent"].ToString()
                ,
                _purchaseTax2 = dt.Rows[i]["PurchaseTaxPercent2"].ToString()
                ,
                _saleRate = dt.Rows[i]["SaleRate"].ToString()
                ,
                _saleTax = dt.Rows[i]["SaleTaxPercent"].ToString()
                ,
                _saleTax2 = dt.Rows[i]["SaleTaxPercent2"].ToString()
                ,
                _mrp = dt.Rows[i]["MRP"].ToString()
                ,
                _barcode = dt.Rows[i]["ItemBarcode"].ToString()
            });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<ReturnItem> getReturnItem(string name, string supplier)
    {
        List<ReturnItem> list = new List<ReturnItem>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE 'ReturnItem','" + supplier + "','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new ReturnItem
            {
                _itemId = dt.Rows[i]["ItemId"].ToString()
                ,
                _id = dt.Rows[i]["ProductCode"].ToString()
                ,
                _description = dt.Rows[i]["Description"].ToString()
                ,
                _color = dt.Rows[i]["ColorName"].ToString()
                ,
                _size = dt.Rows[i]["SizeName"].ToString()
                ,
                _purchaseRate = dt.Rows[i]["PurchaseRate"].ToString()
                ,
                _mrp = dt.Rows[i]["MRP"].ToString()
                ,
                _rack = dt.Rows[i]["Rack"].ToString()
                ,
                _QtyType = dt.Rows[i]["QtyType"].ToString()
            });
        }
        return list;
    }

    [WebMethod(EnableSession=true)]
    public List<GoodsOutItem> getGoodsOutItem(string name)
    {
        List<GoodsOutItem> list = new List<GoodsOutItem>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE 'GoodsOutItem','"+HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString()+"','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new GoodsOutItem
            {
                _itemId = dt.Rows[i]["ItemId"].ToString()
                ,
                _description = dt.Rows[i]["Description"].ToString()
                ,
                //_color = dt.Rows[i]["ColorName"].ToString()
                //,
                //_size = dt.Rows[i]["SizeName"].ToString()
                //,
                _purchaseRate = dt.Rows[i]["PurchaseRate"].ToString()
                ,
                _mrp = dt.Rows[i]["MRP"].ToString()
                ,
                _QtyType = dt.Rows[i]["QtyType"].ToString()
            });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<OrderNo> getOrderNo(string name)
    {
        List<OrderNo> list = new List<OrderNo>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SERVICE 'OrderNo','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "','" + name + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new OrderNo
            {
                _orderNo = dt.Rows[i]["InvoiceNo"].ToString()
                ,
                _branchId = dt.Rows[i]["CreateBranch"].ToString()
                ,
                _branchName = dt.Rows[i]["BranchName"].ToString()
            });
        }
        return list;
    }


    [WebMethod(EnableSession = true)]
    public List<PurchaseOrderNo> getPurchaseOrderNo(string SEARCHTEXT1)
    {
        List<PurchaseOrderNo> list = new List<PurchaseOrderNo>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTO_PURCHASEORDERNO '" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "','" + SEARCHTEXT1 + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new PurchaseOrderNo
            {
                _purchaseorderno = dt.Rows[i]["PurchaseOrderNo"].ToString()
             
            });
        }
        return list;
    }

    public class Color
    {
        public string _id { get; set; }
        public string _colorName { get; set; }
        public string _colorShortName { get; set; }
    }

    public class Size
    {
        public string _id { get; set; }
        public string _sizeName { get; set; }
        public string _sizeShortName { get; set; }
    }

    public class Rack
    {
        public string _id { get; set; }
        public string _rackName { get; set; }
        public string _rackShortName { get; set; }
    }

    public class Supplier
    {
        public string _id { get; set; }
        public string _supplerName { get; set; }
    }

    public class item
    {
        public string _itemId { get; set; }
        public string _id { get; set; }
        public string _brand { get; set; }
        public string _category { get; set; }
        public string _design { get; set; }
        public string _description { get; set; }
        public string _color { get; set; }
        public string _size { get; set; }
        public string _purchaseRate { get; set; }
        public string _purchaseTax { get; set; }
        public string _purchaseTax2 { get; set; }
        public string _saleRate { get; set; }
        public string _saleTax { get; set; }
        public string _saleTax2 { get; set; }
        public string _mrp { get; set; }
        public string _barcode { get; set; }
    }

    public class ReturnItem
    {
        public string _itemId { get; set; }
        public string _id { get; set; }
        public string _description { get; set; }
        public string _color { get; set; }
        public string _size { get; set; }
        public string _purchaseRate { get; set; }
        public string _mrp { get; set; }
        public string _rack { get; set; }
        public string _QtyType { get; set; }
    }

    public class GoodsOutItem
    {
        public string _itemId { get; set; }
        public string _id { get; set; }
        public string _description { get; set; }
        public string _color { get; set; }
        public string _size { get; set; }
        public string _purchaseRate { get; set; }
        public string _mrp { get; set; }
        public string _QtyType { get; set; }
    }

    public class OrderNo
    {
        public string _orderNo { get; set; }
        public string _branchId { get; set; }
        public string _branchName { get; set; }
    }

    public class PurchaseOrderNo
    {
        public string _purchaseorderno { get; set; }
    }

}
