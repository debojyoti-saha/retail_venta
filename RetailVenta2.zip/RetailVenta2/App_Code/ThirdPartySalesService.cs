﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Services;
using Retail.DAL;

/// <summary>
/// Summary description for ThirdPartySalesService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class ThirdPartySalesService : System.Web.Services.WebService
{
    public ThirdPartySalesService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string SalesByDate(string ToDate, string FromDate, string UserName, string Password, string AccessToken)
    {

        DataTable dt = new DataTable();
        if (AccessToken == "frgfgd54df4dfsdAA6d5s6fdf")
        {
            DateTime dt_to = DateTime.ParseExact(ToDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            DateTime dt_from = DateTime.ParseExact(FromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            if ((dt_to - dt_from).TotalDays > 31)
            {
                return "Maximum 31 days data available on API. [ www.TradeSightsWebServices.com ]";
            }


            DBClass db = new DBClass();
            Cryptography crypto = new Cryptography();

            DataTable dt_User_Details = db.getDataTable("SP_USER_AUTHENTICATE '" + UserName + "','" + crypto.Encrypt_SHA(Password, true) + "'");
            bool IsLogin = Convert.ToBoolean(dt_User_Details.Rows[0][0].ToString());

            if (IsLogin)
            {


                dt = db.getDataTable("SP_GET_SALE_REVENUE_REPORT '" + FromDate.Trim() + "','" + ToDate.Trim() + "', " + dt_User_Details.Rows[0]["BranchId"].ToString());
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                Dictionary<string, object> row;
                foreach (DataRow dr in dt.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in dt.Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }
                return serializer.Serialize(rows);
            }
            else
            {
                return "Invalid UserName or Password. Access Denied. [ www.TradeSightsWebServices.com ]";
            }
        }
        else
        {
            return "Invalid Access Token! Please contact with TradeSights for valid Token. [ www.TradeSightsWebServices.com ]";
        }
    }

}
