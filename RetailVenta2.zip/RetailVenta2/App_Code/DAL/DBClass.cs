﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI;

/// <summary>
/// Summary description for DBClass
/// </summary>
/// 
namespace Retail.DAL
{
    public class DBClass
    {
        public DBClass()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        //Sql Connection
        SqlConnection con;

        //Sql Connection
        public SqlConnection connection()
        {
            try
            {
                //con = new SqlConnection("Data Source=111.118.176.13;Initial Catalog=HumaraBazar;User ID=HB_sa;Password=qwaszx@123");
                con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
            }
            catch (SqlException sqlex)
            {
                string strMsg = " (" + sqlex.ErrorCode + ") " + sqlex.Message;
            }
            return con;
        }


        //Close Connection
        public void closeConnection(SqlConnection con)
        {
            try
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (SqlException sqlex)
            {
                string strMsg = " (" + sqlex.ErrorCode + ") " + sqlex.Message;
            }
        }


        //Execute Stored Procedure For Insert
        public string ExecuteSpForInsert(string Procedure_Name, SqlParameterCollection paraList)
        {
            try
            {
                string R = "";
                connection();
                SqlCommand cmd = new SqlCommand(Procedure_Name, con);
                cmd.CommandType = CommandType.StoredProcedure;
                int paractr = paraList.Count;
                SqlParameter para1;
                int i = 0;
                while (i < paractr)
                {
                    para1 = new SqlParameter();
                    para1.ParameterName = paraList[i].ParameterName;
                    para1.Value = paraList[i].Value;
                    para1.Direction = paraList[i].Direction;
                    para1.Size = paraList[i].Size;
                    cmd.Parameters.Add(para1);
                    i++;
                }
                R = cmd.ExecuteNonQuery().ToString();
                return R;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                closeConnection(con);
            }
        }


        //Execute Sp For Return Data Table
        public DataTable ExecuteSpForDT(string usp_name, SqlParameterCollection paraList)
        {
            try
            {
                DataTable dt = new DataTable();
                connection();
                SqlCommand cmd = new SqlCommand(usp_name, con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 100;
                int paractr = paraList.Count;
                SqlParameter para1;
                int i = 0;
                while (i < paractr)
                {
                    para1 = new SqlParameter();
                    para1.ParameterName = paraList[i].ParameterName;
                    para1.Value = paraList[i].Value;
                    para1.Direction = paraList[i].Direction;
                    cmd.Parameters.Add(para1);
                    i++;
                }
                SqlDataAdapter dap = new SqlDataAdapter(cmd);
                dap.Fill(dt);
                return dt;
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                closeConnection(con);
            }
        }
        //For Return Value
        public string returnValue(string str)
        {
            try
            {
                connection();
                string strReturn = "";
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = null;

                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    strReturn = (dr[0].ToString());
                }
                dr.Close();
                return (strReturn);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                closeConnection(con);
            }
        }
        public DataTable getDataTable(String str)
        {
            try
            {
                connection();
                SqlCommand cmd = new SqlCommand(str, con);
                DataTable table = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.SelectCommand.CommandTimeout = 0;
                da.Fill(table);
                return (table);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                closeConnection(con);
            }
        }
        public SqlDataReader returnDataReader(string str)
        {
            try
            {
                connection();
                SqlCommand cmd = new SqlCommand(str, con);
                SqlDataReader dr = null;
                dr = cmd.ExecuteReader();
                dr.Close();
                return dr;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            finally
            {
                closeConnection(con);
            }
        }

        public int validate(string str)
        {
            connection();
            int strReturn = 0;
            SqlCommand cmd = new SqlCommand(str, con);
            SqlDataReader dr = null;
            dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                strReturn = 1;
            }
            dr.Close();
            closeConnection(con);
            return (strReturn);
        }



        public void Fill_Ajax_ComboBox(AjaxControlToolkit.ComboBox c, string fieldName1, string fieldName2, string tableName, string DeletedField, string SelectText, string conditon_field1, string conditon_value1)
        {
            DataTable dt = new DataTable();
            SqlParameterCollection paracoll = new SqlCommand().Parameters;
            SqlParameter para;
            para = new SqlParameter();
            para.ParameterName = "@fieldName1";
            para.Value = fieldName1;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@fieldName2";
            para.Value = fieldName2;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@tableName";
            para.Value = tableName;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@DeletedField";
            para.Value = DeletedField;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@SelectText";
            para.Value = SelectText;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@conditon_field1";
            para.Value = conditon_field1;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@condtion_value1";
            para.Value = conditon_value1;
            paracoll.Add(para);
            dt = ExecuteSpForDT("Sp_Fill_Ajax_Combo", paracoll);
            c.DataSource = dt;
            c.DataTextField = fieldName2;
            c.DataValueField = fieldName1;
            c.DataBind();
            closeConnection(con);

        }
        public void Fill_DropDown(DropDownList c, string fieldName1, string fieldName2, string tableName, string DeletedField, string SelectText, string conditon_field1, string conditon_value1)
        {
            DataTable dt = new DataTable();
            SqlParameterCollection paracoll = new SqlCommand().Parameters;
            SqlParameter para;
            para = new SqlParameter();
            para.ParameterName = "@fieldName1";
            para.Value = fieldName1;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@fieldName2";
            para.Value = fieldName2;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@tableName";
            para.Value = tableName;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@DeletedField";
            para.Value = DeletedField;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@SelectText";
            para.Value = SelectText;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@conditon_field1";
            para.Value = conditon_field1;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@condtion_value1";
            para.Value = conditon_value1;
            paracoll.Add(para);
            dt = ExecuteSpForDT("Sp_Fill_Ajax_Combo", paracoll);
            c.DataSource = dt;
            c.DataTextField = fieldName2;
            c.DataValueField = fieldName1;
            c.DataBind();
            closeConnection(con);

        }


        //Fill Code
        public void Fill_Code(TextBox txtCode, string tabelName, string CodeFormat, string CodeColumn)
        {
            txtCode.Text = returnValue("Exec sp_SELECT_CODE '" + tabelName + "','" + CodeFormat + "','" + CodeColumn + "'");
        }

        public void Fill_AutoID(TextBox txtCode, string tabelName, string CodeFormat, string CodeColumn, string DeleteColumn, string BranchColumn, string Branchid)
        {
            txtCode.Text = returnValue("Exec Get_Auto_Id '" + tabelName + "','" + CodeFormat + "','" + CodeColumn + "','" + DeleteColumn + "','" + BranchColumn + "','" + Branchid + "'");
        }


        public void fill_DropDown(DropDownList d, string fieldName1, string fieldName2, string tableName, string DeletedField, string SelectText, string conditon_field1, string conditon_value1)
        {
            DataTable dt = new DataTable();
            SqlParameterCollection paracoll = new SqlCommand().Parameters;
            SqlParameter para;
            para = new SqlParameter();
            para.ParameterName = "@fieldName1";
            para.Value = fieldName1;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@fieldName2";
            para.Value = fieldName2;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@tableName";
            para.Value = tableName;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@DeletedField";
            para.Value = DeletedField;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@SelectText";
            para.Value = SelectText;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@conditon_field1";
            para.Value = conditon_field1;
            paracoll.Add(para);
            para = new SqlParameter();
            para.ParameterName = "@condtion_value1";
            para.Value = conditon_value1;
            paracoll.Add(para);
            dt = ExecuteSpForDT("Sp_Fill_Ajax_Combo", paracoll);
            d.DataSource = dt;
            d.DataTextField = fieldName2;
            d.DataValueField = fieldName1;
            d.DataBind();
            closeConnection(con);

        }
        public void clearControls(Control parent)
        {
            foreach (Control ctrl in parent.Controls)
            {
                if (ctrl.Controls.Count > 0)
                {
                    clearControls(ctrl);
                }
                else
                {
                    switch (ctrl.GetType().ToString())
                    {
                        case "System.Web.UI.WebControls.TextBox":
                            ((TextBox)ctrl).Text = "";
                            ((TextBox)ctrl).ReadOnly = false;
                            break;
                        case "System.Web.UI.WebControls.ListBox":
                            ((ListBox)ctrl).Items.Clear();
                            break;
                        case "System.Web.UI.WebControls.DropDownList":
                            ((DropDownList)ctrl).SelectedIndex = -1;
                            break;
                        case "System.Web.UI.WebControls.RadioButton":
                            ((RadioButton)ctrl).Checked = false;
                            break;
                        case "System.Web.UI.WebControls.CheckBox":
                            ((CheckBox)ctrl).Checked = false;
                            break;
                        case "System.Web.UI.WebControls.GridView":
                            ((GridView)ctrl).Visible = false;
                            break;
                    }
                }
            }
        }

        public DataSet ExecuteSP2DS(string usp_name, SqlParameterCollection paraList)
        {
            DataSet ds = new DataSet();
            connection();
            SqlCommand cmd = new SqlCommand(usp_name, con);
            cmd.CommandType = CommandType.StoredProcedure;
            int paractr = paraList.Count;
            SqlParameter para1;
            int i = 0;

            while (i < paractr)
            {
                para1 = new SqlParameter();
                para1.ParameterName = paraList[i].ParameterName;
                para1.Value = paraList[i].Value;
                para1.Direction = paraList[i].Direction;
                cmd.Parameters.Add(para1);
                i++;
            }
            SqlDataAdapter dap = new SqlDataAdapter(cmd);
            dap.Fill(ds);
            closeConnection(con);
            return ds;
        }
        public void ExportToExcel(System.Data.DataTable dt, string FileName)
        {
            if (dt.Rows.Count > 0)
            {
                System.IO.StringWriter tw = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                DataGrid dgGrid = new DataGrid();
                dgGrid.DataSource = dt;
                dgGrid.DataBind();

                //Get the HTML for the control.
                dgGrid.RenderControl(hw);
                //Write the HTML back to the browser.
                //Response.ContentType = application/vnd.ms-excel;
                HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";
                HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + FileName + "");
                HttpContext.Current.Response.Write(tw.ToString());
                HttpContext.Current.Response.Flush(); // Sends all currently buffered output to the client.
                HttpContext.Current.Response.SuppressContent = true;  // Gets or sets a value indicating whether to send HTTP content to the client.
                HttpContext.Current.ApplicationInstance.CompleteRequest(); // Causes ASP.NET to bypass all events and filtering in the HTTP pipeline chain of execution and directly execute the EndRequest event.
                HttpContext.Current.Response.End();
            }
        }
    }
}