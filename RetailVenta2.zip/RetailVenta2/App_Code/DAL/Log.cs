﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;


public class Log
{
    public void WriteLine(string message)
    {
        string path = System.Web.Hosting.HostingEnvironment.MapPath("~/Log") + "/" + DateTime.Now.Date.Day + "_" + DateTime.Now.Date.Month + ".txt";
        //FileInfo file = new FileInfo(path);
        //if (file.Exists)
        //{


        //}
        //else
        //{
        //    file.Create();
        //}
        File.AppendAllText(path, DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt") + Environment.NewLine);
        File.AppendAllText(path, message + Environment.NewLine);
        File.AppendAllText(path, "=========================================================================" + Environment.NewLine);
    }
}
