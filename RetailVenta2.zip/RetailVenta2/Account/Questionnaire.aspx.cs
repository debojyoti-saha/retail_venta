﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using Retail.DAL;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Account_Questionnaire : System.Web.UI.Page
{
    DBClass db = new DBClass();
    GlobalClass gc = new GlobalClass();
    DataTable dt = new DataTable();
    Cryptography cr = new Cryptography();
    string UserId;
    protected void Page_Load(object sender, EventArgs e)
    {
        UserId = Request.Cookies["UserCookies"]["UserId"].ToString();
        if (!IsPostBack)
        {

            dt = db.getDataTable("SP_FETCH_QUESTIONS");
            gvQuestions.DataSource = dt;
            gvQuestions.DataBind();
            //gc.FillCheckBox(chkbxlistQuestions, "SP_FETCH_QUESTIONS", "Questions", "QuestionId");
        }

        if (Request.Cookies["UserCookies"]["type"].ToString() == "SupperAdmin")
        {
            Response.RedirectPermanent("~/Account/Logout.aspx");
        }
    }

    protected void btnLogout_Click(object sender, EventArgs e)
    {
        try
        {

            if (((RadioButtonList)gvQuestions.Rows[4].FindControl("rbtn_Yes_No")).SelectedIndex == 0)
            {
                Response.Clear();
                System.IO.StringWriter stringWrite = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter htmlWrite = new HtmlTextWriter(stringWrite);
                gvQuestions.RenderControl(htmlWrite);
                string Branch = db.returnValue("select BranchName from tblBranch where BranchId=" + Request.Cookies["UserCookies"]["Branch"].ToString());
                string message = "Dear Sir,<br>Store <b>" + Branch + "</b> has been closed for the day.<br><br>" + stringWrite.ToString();
                cr.SendMail(ConfigurationManager.ConnectionStrings["AdminEmail"].ConnectionString, "", "Store/Branch Closed", message);
            }

            DataTable dt_questions = new DataTable();
            dt_questions.Columns.Add("QuestionId");
            dt_questions.Columns.Add("IsCheked");
            dt_questions.Columns.Add("Remarks");
            for (int i = 0; i < gvQuestions.Rows.Count; i++)
            {
                Label lbl_QuestionId = (Label)(gvQuestions.Rows[i].FindControl("lbl_QuestionId"));
                RadioButtonList rbtn_cheked = (RadioButtonList)(gvQuestions.Rows[i].FindControl("rbtn_Yes_No"));
                TextBox txt_remarks = (TextBox)(gvQuestions.Rows[i].FindControl("txt_Remarks"));
                dt_questions.Rows.Add(lbl_QuestionId.Text, rbtn_cheked.SelectedValue, txt_remarks.Text);
            }

            SqlParameterCollection paracol = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.Value = dt_questions;
            para.ParameterName = "@DT";
            paracol.Add(para);

            para = new SqlParameter();
            para.Value = UserId;
            para.ParameterName = "@USERID";
            paracol.Add(para);
            db.ExecuteSpForDT("SP_INSERT_QUESTIONS", paracol);


            FormsAuthentication.SignOut();

            Response.Redirect("~/Account/Login.aspx");
            //Response.RedirectPermanent("~/Account/Logout.aspx");

        }
        catch (Exception ex)
        {

        }


    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        // Confirms that an HtmlForm control is rendered for the
        // specified ASP.NET server control at run time.
        // No code required here.
    }


}