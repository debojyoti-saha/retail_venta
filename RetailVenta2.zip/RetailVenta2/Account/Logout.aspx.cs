﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using Retail.DAL;

public partial class Account_Logout : System.Web.UI.Page
{
    DBClass db = new DBClass();
    GlobalClass gc = new GlobalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        FormsAuthentication.SignOut();
        Response.RedirectPermanent("~/Account/Login.aspx");
        //if (Request.Cookies["UserCookies"]["type"].ToString() != "SupperAdmin")
        //{
        //    Response.RedirectPermanent("~/Account/Questionnaire.aspx");
        //}
        //else
        //{
        //    FormsAuthentication.SignOut();

        //    Response.RedirectPermanent("~/Account/Login.aspx");
        //}
    }
}