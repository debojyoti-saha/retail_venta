﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;
using System.Web.Security;
using System.Configuration;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text;
using Retail.DAL;

public partial class Account_Settings : System.Web.UI.Page
{
    string sUserName;
    string sLocationCode;

    bool checkUserName;
    SqlTransaction transaction;
    string userid = "";
    DBClass db = new DBClass();
    Cryptography crypto = new Cryptography();
    DataTable dt_User_Details;
    CustomValidator validator;


    protected void Page_Load(object sender, EventArgs e)
    {
        sUserName = HttpContext.Current.User.Identity.Name;
        //sUserName = (string)Session["User_Name"];
        //sLocationCode = (string)Session["LocationCode"];

        if (!Page.IsPostBack)
        {
            view();
        }
    }

    private void SessionUserNameShow()
    {
        string userIdtext = (string)(Session["uid"]);
        string userNametext = (string)(Session["uname"]);
        string UserTypetext = (string)(Session["utype"]);
        string UserCompleteName = (string)(Session["CompleteName"]);
        if (Session["uname"] != null)
        {

            userid = userIdtext;

        }
        else
        {
            Session["uname"] = null;
            Session.Clear();
            Session.Abandon();
            Response.Redirect("../Account/Login.aspx");
        }
    }
        public void view()
        {


            string sSQL = "SP_USER_INFO @USER_NAME='"+sUserName+"'";
            SqlParameter[] p1 = new SqlParameter[1];
            p1 = null;
            DataTable dt = db.getDataTable("SP_USER_INFO @USER_NAME='" + sUserName + "'");
            txtUserFirstName.Text = dt.Rows[0]["CompleteName"].ToString();
            txtMobile.Text = dt.Rows[0]["CellNumber"].ToString();
            txtEmail.Text = dt.Rows[0]["EmailAddress"].ToString();
            txtPhone.Text = dt.Rows[0]["PhoneNumber"].ToString();
            txtStreetName.Text = dt.Rows[0]["StreetAddress"].ToString();
            txtCity.Text = dt.Rows[0]["CityTown"].ToString();
            txtState.Text = dt.Rows[0]["StateProv"].ToString();


        }

    }
