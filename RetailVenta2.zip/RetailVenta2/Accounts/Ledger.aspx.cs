﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Retail.DAL;
using System.Data.SqlClient;

public partial class Accounts_Ledger : System.Web.UI.Page
{
    DBClass db = new DBClass();
    Validator val = new Validator();
    CustomValidator cval = new CustomValidator();
    GlobalClass gc = new GlobalClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable dt = db.getDataTable("SP_GET_ACCOUNTS");
            ddlAccounts.DataSource = dt;
            ddlAccounts.DataTextField = "AccountName";
            ddlAccounts.DataValueField = "AccountCode";
            ddlAccounts.DataBind();

            FillLedgerAccount();
        }
    }

    public void FillLedgerAccount()
    {
        DataTable dt = db.getDataTable("SP_LEDGER_ACCOUNT "+Request.Cookies["UserCookies"]["Branch"].ToString());
        rblLedgerAccounts.DataSource = dt;
        rblLedgerAccounts.DataTextField = "Ledger_name";
        rblLedgerAccounts.DataValueField = "ID";
        rblLedgerAccounts.DataBind();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        InsertUpdateLedger("Insert");
    }
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        if (rblLedgerAccounts.SelectedValue.Trim() != "")
        {
            hdnLedgerId.Value = rblLedgerAccounts.SelectedValue.Trim();
            DataTable dt = db.getDataTable("SP_GET_LEDGER_ACCOUNT_DETAILS " + hdnLedgerId.Value);
            txtName.Text = dt.Rows[0]["Ledger_Name"].ToString();
            txtAlias.Text = dt.Rows[0]["Alias"].ToString();
            ddlAccounts.SelectedValue = dt.Rows[0]["UnderAccount"].ToString();
            txtMellingName.Text = dt.Rows[0]["MellingName"].ToString();
            txtAddress.Text = dt.Rows[0]["Address"].ToString();
            txtState.Text = dt.Rows[0]["State"].ToString();
            txtPinCode.Text = dt.Rows[0]["Pincode"].ToString();
            txtPanNo.Text = dt.Rows[0]["PanNo"].ToString();
            txtSalesTaxNo.Text = dt.Rows[0]["SalesTaxNo"].ToString();
            txtCstNo.Text = dt.Rows[0]["CstNo"].ToString();
            chkOnBranch.Checked = Convert.ToBoolean(dt.Rows[0]["OnBranch"].ToString());
            txtOpeningBalence.Text = dt.Rows[0]["OpeningBalence"].ToString();


            btnAdd.Enabled = false;
            btnDelete.Enabled = false;
            btnEdit.Visible = false;
            btnUpdate.Visible = true;
        }
        else
        {
            val.SetMessage(this, ValidationSummary_main, cval, "Main", "Please select a Ledger account!", "error");
        }
    }

    public void InsertUpdateLedger(string mode)
    {
        try
        {
            SqlParameterCollection paracol = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@MODE";
            para.Value = mode;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@ID";
            para.Value = hdnLedgerId.Value;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@NAME";
            para.Value = txtName.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@ALIAS";
            para.Value = txtAlias.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@ON_BRANCH";
            para.Value = chkOnBranch.Checked;
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@BRANCH";
            para.Value = Request.Cookies["UserCookies"]["Branch"].Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@UNDER_ACCOUNT";
            para.Value = ddlAccounts.SelectedValue.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@OPENING_BALENCE";
            para.Value = txtOpeningBalence.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@MELLING_NAME";
            para.Value = txtMellingName.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@ADDRESS";
            para.Value = txtAddress.Text.ToString();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@STATE";
            para.Value = txtState.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@PINCODE";
            para.Value = txtPinCode.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@PAN_NO";
            para.Value = txtPanNo.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@SALES_TAX_NO";
            para.Value = txtSalesTaxNo.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@CST_NO";
            para.Value = txtCstNo.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@USER";
            para.Value = Request.Cookies["UserCookies"]["UserId"].Trim();
            paracol.Add(para);

            string message = db.ExecuteSpForInsert("SP_INSERT_UPDATE_LEDGER_ACCOUNT", paracol);

            val.SetMessage(this, ValidationSummary_main, cval, "Main", "New Ledger enter Successful", "success");
            gc.ClearInputs(this.Controls);

            FillLedgerAccount();


            hdnLedgerId.Value = "";
            chkOnBranch.Checked = false;
            btnAdd.Enabled = true;
            btnDelete.Enabled = true;
            btnEdit.Visible = true;
            btnUpdate.Visible = false;
        }
        catch (Exception ex)
        {
            val.SetMessage(this, ValidationSummary_main, cval, "Main", ex.Message, "error");
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        InsertUpdateLedger("Update");
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            if (rblLedgerAccounts.SelectedValue.Trim() != "")
            {
                string MESSAGE = db.returnValue("SP_DELETE_LEDGER_ACCOUNT " + rblLedgerAccounts.SelectedValue.ToString());
                val.SetMessage(this, ValidationSummary_main, cval, "Main", "Ledger Account Delete Successfully!", "success");
                FillLedgerAccount();
            }
            else
            {
                val.SetMessage(this, ValidationSummary_main, cval, "Main", "Please select a Ledger account!", "error");
            }
        }
        catch
        {
            return;
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        gc.ClearInputs(this.Controls);
        btnAdd.Enabled = true;
        btnEdit.Visible = true;
        btnDelete.Enabled = true;
        btnUpdate.Visible = false;
    }
}