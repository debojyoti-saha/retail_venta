﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Retail.DAL;
using Microsoft.Reporting.WebForms;

public partial class Accounts_CashBook : System.Web.UI.Page
{
    DBClass db = new DBClass();
    GlobalClass gc = new GlobalClass();
    Validator val = new Validator();
    CustomValidator cval = new CustomValidator();
    protected void Page_Load(object sender, EventArgs e)
    {

        ScriptManager.RegisterStartupScript(this, this.GetType(), "do", "javascript:_Do_work_();", true);
        if (!IsPostBack)
        {
            gc.FillDropDown(ddlBranch, "spFillMaster 'branch'", "BranchName", "BranchId", "-- Select Branch --");
            txtToDate.Text=txtFromDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            SqlParameterCollection paracol = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@TO_DATE";
            para.Value = txtToDate.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@FROM_DATE";
            para.Value = txtFromDate.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@BRANCH_ID";
            para.Value = ddlBranch.SelectedValue.ToString();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@CASH_ID";
            para.Value = hdnLedgerAutoFillCode.Value;
            paracol.Add(para);

            DataTable dt = db.ExecuteSpForDT("SP_CASH_BOOK", paracol);


            Page.Header.Title = "Cash Book";
            ReportViewer1.ProcessingMode = ProcessingMode.Local;
            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Accounts/CashBook.rdlc");

            ReportDataSource datasource1 = new ReportDataSource("dsCashBook", dt);

            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.DataSources.Add(datasource1);
            ReportViewer1.ServerReport.Refresh();
        }
        catch (Exception ex)
        {
            val.SetMessage(this, ValidationSummary1, cval, "", ex.Message, "error");
        }
    }




}