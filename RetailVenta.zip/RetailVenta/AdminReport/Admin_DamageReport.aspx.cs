﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;
using System.Data.SqlClient;

public partial class Report_DamageReport : System.Web.UI.Page
{
    DBClass db = new DBClass();
    Validator val = new Validator();
    GlobalClass gc = new GlobalClass();
    CustomValidator cval = new CustomValidator();
    protected void Page_Load(object sender, EventArgs e)
    {
        ScriptManager scriptManager = ScriptManager.GetCurrent(this.Page);
        scriptManager.RegisterPostBackControl(this.btnExport);
        ScriptManager.RegisterStartupScript(this, this.GetType(), "do", "javascript:_do_task();", true);
        if (!IsPostBack)
        {
            gc.FillDropDown(ddlBranch, "spFillMaster 'branch'", "BranchName", "BranchId", "-- Select Branch --");
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        gvDamageDetails.Visible = false;
        gvProductWise.Visible = false;
        gvSupplierWise.Visible = false;
        try
        {
            SqlParameterCollection paracol = new SqlCommand().Parameters;
            SqlParameter para;

            para = new SqlParameter();
            para.ParameterName = "@MODE";
            para.Value = rbtnSearchMode.SelectedValue.ToString();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@FROM_DATE";
            para.Value = txtFromDate.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@TO_DATE";
            para.Value = txtTodate.Text.Trim();
            paracol.Add(para);

            para = new SqlParameter();
            para.ParameterName = "@BRANCH";
            para.Value = ddlBranch.SelectedValue.ToString();
            paracol.Add(para);

            DataTable dt = db.ExecuteSpForDT("SP_GET_DAMAGE_REPORT", paracol);
            Session["Damage_dt"] = dt;

            if (rbtnSearchMode.SelectedValue == "1")
            {
                gvDamageDetails.DataSource = dt;
                gvDamageDetails.DataBind();
                gvDamageDetails.Visible = true;
            }
            else if (rbtnSearchMode.SelectedValue == "2")
            {
                gvProductWise.DataSource = dt;
                gvProductWise.DataBind();
                gvProductWise.Visible = true;
            }
            else if (rbtnSearchMode.SelectedValue == "3")
            {
                gvSupplierWise.DataSource = dt;
                gvSupplierWise.DataBind();
                gvSupplierWise.Visible = true;
            }
        }
        catch (Exception ex)
        {
            val.SetMessage(this, ValidationSummary1, cval, "", ex.Message, "error");
        }
    }
    protected void gvDamageDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvDamageDetails.PageIndex = e.NewPageIndex;
        gvDamageDetails.DataSource = Session["Damage_dt"];
        gvDamageDetails.DataBind();
    }
    protected void gvProductWise_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvProductWise.PageIndex = e.NewPageIndex;
        gvProductWise.DataSource = Session["Damage_dt"];
        gvProductWise.DataBind();
    }
    protected void gvSupplierWise_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvSupplierWise.PageIndex = e.NewPageIndex;
        gvSupplierWise.DataSource = Session["Damage_dt"];
        gvSupplierWise.DataBind();
    }

    protected void btnGraph_Click(object sender, EventArgs e)
    {

        //Modal_Graph.Show();
        ScriptManager.RegisterStartupScript(this, this.GetType(), "graph", "javascript:_Do_Work_Report()", true);
    }
    protected void gvSupplierWise_DataBound(object sender, EventArgs e)
    {
        for (int rowIndex = gvSupplierWise.Rows.Count - 2; rowIndex >= 0; rowIndex--)
        {

            GridViewRow row = gvSupplierWise.Rows[rowIndex];
            GridViewRow previousRow = gvSupplierWise.Rows[rowIndex + 1];
            string labno = ((Label)row.Cells[0].FindControl("txtSupplierCode")).Text.Trim();
            //string desciplineId = ((HiddenField)previousRow.Cells[1].FindControl("hfDisciplineId")).Value.Trim();
            //string desciplineIdPrev = ((HiddenField)row.Cells[1].FindControl("hfDisciplineId")).Value.Trim();
            string labnoPrev = ((Label)previousRow.Cells[1].FindControl("txtSupplierCode")).Text.Trim();


            if (labno == labnoPrev)
            {
                row.Cells[2].RowSpan = previousRow.Cells[2].RowSpan < 2 ? 2 : previousRow.Cells[2].RowSpan + 1;
                row.Cells[1].RowSpan = previousRow.Cells[1].RowSpan < 2 ? 2 : previousRow.Cells[1].RowSpan + 1;
                previousRow.Cells[2].Visible = false;
                previousRow.Cells[1].Visible = false;
            }
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        try
        {
            DataTable dt = ((DataTable)Session["Damage_dt"]).Copy();
            db.ExportToExcel(dt, "DamageReport.xls");
        }
        catch
        {
            return;
        }
    }
}