﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;
using System.Web.Security;

public partial class Accounts_Login : System.Web.UI.Page
{
    DBClass db = new DBClass();
    Cryptography crypto = new Cryptography();
    DataTable dt_User_Details;
    CustomValidator validator = new CustomValidator();
    CustomValidator val;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // Add new attribute to form1 event to fire when enter key submit button click event

            form1.Attributes.Add("onkeydown", "javascript: return WebForm_FireDefaultButton (event, '" + btnSubmit.ClientID + "')");

            // Allow you to use enter key for sumbit data
            ClientScript.RegisterHiddenField("__EVENTTARGET", "btnSubmit");


            string success = Request.QueryString["Message"] as string;
            if (success != null && success !="")
            {
                val = new CustomValidator();
                val.ErrorMessage = success;
                val.IsValid = false;
               // val.ValidationGroup = "LoginUserValidationGroup";
                Page.Validators.Add(val);
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Log log = new Log();
        log.WriteLine("Login");
        try
        {
            if (CheckUser(UserName.Text.ToString(), Password.Text.ToString()))
            {
                //Login successful lets put him to requested page
                string returnUrl = Request.QueryString["ReturnUrl"] as string;

                if (true)
                {
                    var ticket = new FormsAuthenticationTicket(2, dt_User_Details.Rows[0]["Username"].ToString(), DateTime.Now, DateTime.Now.AddMinutes(120), true,
                                                               string.Empty, FormsAuthentication.FormsCookiePath);
                    var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket))
                    {
                        Domain = FormsAuthentication.CookieDomain,
                        Expires = DateTime.Now.AddMinutes(120),
                        HttpOnly = true,
                        Secure = FormsAuthentication.RequireSSL,
                        Path = FormsAuthentication.FormsCookiePath
                    };
                    Response.Cookies.Add(cookie);
                    //Response.Redirect(FormsAuthentication.GetRedirectUrl(returnUrl, true));
                }

                Response.Cookies["UserCookies"]["UserId"] = dt_User_Details.Rows[0]["UserId"].ToString();
                Response.Cookies["UserCookies"]["name"] = dt_User_Details.Rows[0]["CompleteName"].ToString();
                Response.Cookies["UserCookies"]["type"] = dt_User_Details.Rows[0]["AdminType"].ToString();
                Response.Cookies["UserCookies"]["Branch"] = dt_User_Details.Rows[0]["BranchId"].ToString();
                Response.Cookies["UserCookies"].Expires = DateTime.UtcNow.AddYears(50);

                if (returnUrl != null)
                {
                    Response.Redirect(returnUrl, false);
                }
                else
                {
                    //no return URL specified so lets kick him to home page
                    DataTable dt_logintime = db.getDataTable("SP_UPDATE_USER_LOGIN_TIME '" + Request.Cookies["UserCookies"]["UserId"].ToString() + "'");
                    Session["LastLoginTime"] = dt_logintime.Rows[0]["LastLogin"].ToString();
                    Response.Redirect("~/Retail/Home.aspx", false);
                }


            }
            else
            {
                val = new CustomValidator();
                val.ErrorMessage = "Invalid User name or Password";
                val.IsValid = false;
                //val.ValidationGroup = "LoginUserValidationGroup";
                Page.Validators.Add(val);
            }
            
            log.WriteLine("Login Succes");
        }
        catch(Exception ex)
        {
            log.WriteLine(ex.ToString());
        }
    }

    public bool CheckUser(string username, string password)
    {
        try
        {
            dt_User_Details = db.getDataTable("SP_USER_AUTHENTICATE '" + username + "','" + crypto.Encrypt_SHA(password, true) + "'");
            return Convert.ToBoolean(dt_User_Details.Rows[0][0].ToString());
        }
        catch(Exception ex)
        {
            Log log = new Log();
            log.WriteLine(ex.ToString());
            return false;
        }
    }

    protected void FormsAuthentication_OnAuthenticate(Object sender, FormsAuthenticationEventArgs e)
    {
        if (FormsAuthentication.CookiesSupported == true)
        {
            if (Request.Cookies[FormsAuthentication.FormsCookieName] != null)
            {
                try
                {
                    //let us take out the username now                
                    string username = FormsAuthentication.Decrypt(Request.Cookies[FormsAuthentication.FormsCookieName].Value).Name;

                    //let us extract the roles from our own custom cookie
                    string roles = "User";

                    //Let us set the Pricipal with our user specific details
                    e.User = new System.Security.Principal.GenericPrincipal(
                      new System.Security.Principal.GenericIdentity(username, "Forms"), roles.Split(';'));
                }
                catch (Exception)
                {
                    //somehting went wrong
                }
            }
        }
    }
}