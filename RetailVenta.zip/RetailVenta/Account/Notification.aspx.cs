﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.Data;

public partial class Account_Notification : System.Web.UI.Page
{
    DBClass db = new DBClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataTable dt = db.getDataTable("SP_GET_ALL_NOTIFICATION_USER_WISE " + Request.Cookies["UserCookies"]["UserId"].ToString());
            gvNotificationDetails.DataSource = dt;
            gvNotificationDetails.DataBind();
        }
    }
    protected void gvNotificationDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvNotificationDetails.PageIndex = e.NewPageIndex;
        DataTable dt = db.getDataTable("SP_GET_ALL_NOTIFICATION_USER_WISE " + Request.Cookies["UserCookies"]["UserId"].ToString());
        gvNotificationDetails.DataSource = dt;
        gvNotificationDetails.DataBind();
    }
}