﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Configuration;
using Retail.DAL;
using MSUtil;
using Microsoft.Reporting.WebForms;
using System.Web.Security;

public partial class Account_UserLoginDetail : System.Web.UI.Page
{
    System.Configuration.AppSettingsReader settingsReader = new AppSettingsReader();
    string Path = "";
    GlobalClass gc = new GlobalClass();
    CustomValidator cval = new CustomValidator();
    Validator val = new Validator();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Path = (string)settingsReader.GetValue("LogFolderPath", typeof(String));
            DataTable ReportsDT = new DataTable("ReportsDT");
            ReportsDT.Columns.Add("Name");
            ReportsDT.Columns.Add("FolderName");
            ReportsDT.Columns.Add("CreateMonth");
            DirectoryInfo DirInfo = new DirectoryInfo(Server.MapPath("../LogFiles/" + Path));
            DataRow ReportDTRow = ReportsDT.NewRow();
            foreach (FileInfo fi in DirInfo.GetFiles("*.*", SearchOption.AllDirectories))
            {
                ReportDTRow = ReportsDT.NewRow();
                ReportDTRow["Name"] = fi.Name;
                ReportDTRow["FolderName"] = fi.FullName;
                ReportDTRow["CreateMonth"] = fi.LastWriteTime.ToString("MMM") + " - " + fi.LastWriteTime.ToString("yyyy");
                ReportsDT.Rows.Add(ReportDTRow);
            }
            ReportsDT.AcceptChanges();
            ddlMonth.DataSource = ReportsDT;
            ddlMonth.DataTextField = "CreateMonth";
            ddlMonth.DataValueField = "Name";
            ddlMonth.DataBind();
            ddlMonth.Items.Insert(0, new ListItem("-- Select a Month --", "default.log"));
        }
    }
    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
        Path = (string)settingsReader.GetValue("LogFolderPath", typeof(String));
        ////Open the file in a stream reader.
        //StreamReader s = new StreamReader(Server.MapPath("../LogFiles/" + Path + "/" + ddlMonth.SelectedValue));
        //try
        //{
        //    string delimiter = " \t";
        //    string TableName = "Log";



        //    //The DataSet to Return
        //    DataSet result = new DataSet();

        //    //Split the first line into the columns       
        //    string[] columns = s.ReadLine().Split(delimiter.ToCharArray());
        //    columns = s.ReadLine().Split(delimiter.ToCharArray());
        //    columns = s.ReadLine().Split(delimiter.ToCharArray());
        //    columns = s.ReadLine().Split(delimiter.ToCharArray());

        //    //Add the new DataTable to the RecordSet
        //    result.Tables.Add(TableName);

        //    //Cycle the colums, adding those that don't exist yet 
        //    //and sequencing the one that do.
        //    foreach (string col in columns)
        //    {
        //        bool added = false;
        //        string next = "";
        //        int i = 0;
        //        while (!added)
        //        {
        //            //Build the column name and remove any unwanted characters.
        //            string columnname = col + next;
        //            columnname = columnname.Replace("#", "");
        //            columnname = columnname.Replace("Fields:", "");
        //            columnname = columnname.Replace("'", "");
        //            columnname = columnname.Replace("&", "");

        //            //See if the column already exists
        //            if (!result.Tables[TableName].Columns.Contains(columnname) && columnname != "")
        //            {
        //                //if it doesn't then we add it here and mark it as added
        //                result.Tables[TableName].Columns.Add(columnname);

        //            }
        //            added = true;
        //            //else
        //            //{
        //            //    //if it did exist then we increment the sequencer and try again.
        //            //    i++;
        //            //    next = "_" + i.ToString();
        //            //}
        //        }
        //    }

        //    //Read the rest of the data in the file.        
        //    string AllData = s.ReadToEnd();

        //    //Split off each row at the Carriage Return/Line Feed
        //    //Default line ending in most windows exports.  
        //    //You may have to edit this to match your particular file.
        //    //This will work for Excel, Access, etc. default exports.
        //    string[] rows = AllData.Split("\r\n".ToCharArray());

        //    //Now add each row to the DataSet        
        //    foreach (string r in rows)
        //    {
        //        //Split the row at the delimiter.
        //        string[] items = r.Split(delimiter.ToCharArray());

        //        //Add the item
        //        result.Tables[TableName].Rows.Add(items);
        //    }



        //    GridView1.DataSource = result;
        //    GridView1.DataBind();
        //}
        //catch(Exception ex)
        //{
        //    val.SetMessage(this, ValidationSummary1, cval, "", ex.Message, "error");
        //}
        //finally
        //{
        //    s.Close();
        //}

        DataTable dt = ParseLog<COMW3CInputContextClassClass>(@"select date ,cs-username as cs_username,time,cs-uri-stem as cs_uri_stem, c-Ip as Ip, cs-bytes as Upload ,sc-bytes as Download, time-taken as time_taken from " + Server.MapPath("../LogFiles/" + Path + "/" + ddlMonth.SelectedValue) + " where cs-uri-stem like '%.aspx%' and cs-username like '%" 
            + 
            User.Identity.Name
            + "%' ");
        //GridView1.DataSource = dt;
        //GridView1.DataBind();

        Page.Header.Title = "";
        ReportViewer1.ProcessingMode = ProcessingMode.Local;
        ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report/UserLog.rdlc");
        ReportDataSource datasource1 = new ReportDataSource("dsUserLog", dt);
        ReportViewer1.LocalReport.DataSources.Clear();
        ReportViewer1.LocalReport.DataSources.Add(datasource1);
        ReportViewer1.ServerReport.Refresh();
    }

    public static Type[] types = new Type[] 
{  
    Type.GetType("System.Int32"), 
    Type.GetType("System.Single"),
    Type.GetType("System.String"), 
    Type.GetType("System.DateTime"),
    Type.GetType("System.Nullable")
};

    public static DataTable ParseLog<T>(string query) where T : new()
    {
        LogQueryClassClass log = new LogQueryClassClass();
        ILogRecordset recordset = log.Execute(query, new T());
        ILogRecord record = null;

        DataTable dt = new DataTable();
        Int32 columnCount = recordset.getColumnCount();

        for (int i = 0; i < columnCount; i++)
        {
            dt.Columns.Add(recordset.getColumnName(i), types[recordset.getColumnType(i) - 1]);
        }

        for (; !recordset.atEnd(); recordset.moveNext())
        {
            DataRow dr = dt.NewRow();

            record = recordset.getRecord();

            for (int i = 0; i < columnCount; i++)
            {
                dr[i] = record.getValue(i);
            }
            dt.Rows.Add(dr);
        }
        return dt;
    }
}