﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Retail.DAL;
using System.IO;

public partial class Account_Image : System.Web.UI.Page
{
    DBClass db = new DBClass();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FetchImage(Session["UserImage"]);
        }
    }

    protected void FetchImage(object image)
    {
        try
        {
            byte[] bytes = (byte[])image;
            string base64String = Convert.ToBase64String(bytes, 0, bytes.Length);
            imgItem.ImageUrl = "data:image/png;base64," + base64String;
            //Session["UserImage"] = image;
        }
        catch
        {
            imgItem.ImageUrl = "../Images/no_image_found.jpg";
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string ImageName = string.Empty;
        byte[] Image = null;

        ImageName = Path.GetFileName(ImageUpload.FileName);
        Image = new byte[ImageUpload.PostedFile.ContentLength];
        HttpPostedFile UploadedImage = ImageUpload.PostedFile;
        UploadedImage.InputStream.Read(Image, 0, (int)ImageUpload.PostedFile.ContentLength);
        FetchImage(Image);
        Session["UserImage"] = Image;
    }
}