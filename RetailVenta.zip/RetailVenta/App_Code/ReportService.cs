﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using Retail.DAL;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ReportService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class ReportService : System.Web.Services.WebService
{
    DBClass db = new DBClass();
    public ReportService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public data GetReport(string a)
    {
        Random _r = new Random();
        data data = new data();
        List<XYvalue> value = new List<XYvalue>();
        for (int i = 0; i < 10; i++)
        {
            
            value.Add(new XYvalue{
                x=i.ToString()
                ,
                y= _r.Next(50).ToString()
            });
        }

        data.key = "Sales";
        data.color = "Red";
        data.values = value;


        return data;
    }


    [WebMethod]
    public List<dv1> DashBoard(string a)
    {
        List<dv1> dv = new List<dv1>();

        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_DASHBOARD_PERFORMENCE '"+HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString()+"'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            dv.Add(new dv1 { 
                date = dt.Rows[i]["_DATE"].ToString()
                ,
                sales = Convert.ToDecimal(dt.Rows[i]["_SALES"].ToString())
                ,
                expenses = Convert.ToDecimal(dt.Rows[i]["_EXPENSES"].ToString())
                ,
                purchase = Convert.ToDecimal(dt.Rows[i]["_PURCHASE"].ToString())
            });
        }

        return dv;
    }

    [WebMethod]
    public List<stockItem> DashBoard_StockMeter(string a)
    {
        List<stockItem> item = new List<stockItem>();

        DataTable dt = new DataTable();

        if (a == "top")
        {
            dt = db.getDataTable("SP_GET_CURRENT_TOP_STOCK '1','','','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "'");

        }
        else if (a == "buttom")
        {
            dt = db.getDataTable("SP_GET_CURRENT_TOP_STOCK '2','','','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "'");
        }


        for (int i = 0; i < dt.Rows.Count; i++)
        {
            item.Add(new stockItem
            {
                Qty = dt.Rows[i]["QTY1"].ToString()
                ,
                ProductCode = dt.Rows[i]["PRODUCTCODE"].ToString()
                ,
                PrintName = dt.Rows[i]["PrintName"].ToString()
            });
        }
        return item;
    }

    [WebMethod]
    public List<UserData> User_Update(string a)
    {
        List<UserData> list = new List<UserData>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_USER_UPDATE " + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "," + HttpContext.Current.Request.Cookies["UserCookies"]["UserId"].ToString());
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new UserData
            {
                GOODS_IN = dt.Rows[i]["GOODS_IN"].ToString()
                ,
                GOODS_OUT = dt.Rows[i]["GOODS_OUT"].ToString()
                ,
                SALE_AMOUNT = dt.Rows[i]["USER_SALE"].ToString()
                ,
                BILL_COUNT = dt.Rows[i]["USER_BILL_COUNT"].ToString()
                ,
                TOP_USER = dt.Rows[i]["TOP_USER"].ToString()
            });
        }
        return list;
    }

    [WebMethod]
    public List<thread> DashBoard_Thread(string a)
    {
        List<thread> list = new List<thread>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_LIVE_THREAD " + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString());
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new thread
            {
                TOTAL_QTY = dt.Rows[i]["TOTAL_QTY"].ToString()
                ,
                PURCHASE_AMOUNT = dt.Rows[i]["PURCHASE_AMOUNT"].ToString()
                ,
                SALE_AMOUNT = dt.Rows[i]["SALE_AMOUNT"].ToString()
                ,
                BRANCH_ONLINE = dt.Rows[i]["BRANCH_ONLINE"].ToString()
                ,
                USER_ONLINE = "0" //dt.Rows[i]["USER_ONLINE"].ToString()
                ,
                PURCHASE_QTY = dt.Rows[i]["PURCHASE_QTY"].ToString()
                ,
                SALE_QTY = dt.Rows[i]["SALE_QTY"].ToString()
                ,
                LAST_BILL = dt.Rows[i]["LAST_BILL"].ToString()
            });
        }
        return list;
    }

    [WebMethod]
    public List<salesData> MISSales(string branch)
    {
        List<salesData> list = new List<salesData>();
        string current_Year = DateTime.Now.Year.ToString(), previous_Year = (Convert.ToInt32(DateTime.Now.Year.ToString()) - 1).ToString();
        for (int i = 1; i <= 12; i++)
        {
            list.Add(new salesData {
                Month = MonthName(i)
                    ,
                    CurrentYear = value(db.returnValue("SP_MIS_SALES_YEAR_WISE '"+branch+"','" + current_Year + "','" + i + "'"))
                    ,
                    PreviousYear = value(db.returnValue("SP_MIS_SALES_YEAR_WISE '" + branch + "','" + previous_Year + "','" + i + "'"))
            });
            //DataRow dr = dt.NewRow();
            //dr[0] = i.ToString();
            //dr[1] = value(db.returnValue("SP_MIS_SALES_YEAR_WISE '" + current_Year + "','" + i + "'"));
            //dr[2] = value(db.returnValue("SP_MIS_SALES_YEAR_WISE '" + previous_Year + "','" + i + "'"));
            //dt.Rows.Add(dr);
            //dt.AcceptChanges();

        }



        return list;
    }

    [WebMethod]
    public List<rptData> DamageReport(string searchMode, string fromDate, string toDate)
    {
        List<rptData> datas = new List<rptData>();

        SqlParameterCollection paracol = new SqlCommand().Parameters;
        SqlParameter para;

        para = new SqlParameter();
        para.ParameterName = "@MODE";
        para.Value = searchMode;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@FROM_DATE";
        para.Value = fromDate;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@TO_DATE";
        para.Value = toDate;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@BRANCH";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString();
        paracol.Add(para);

        DataTable dt = db.ExecuteSpForDT("SP_GET_DAMAGE_REPORT", paracol);

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            datas.Add(new rptData
            {
                ID = dt.Rows[i][0].ToString()
                ,
                Value = dt.Rows[i][1].ToString()
                ,
                Qty = Convert.ToDecimal(dt.Rows[i][2].ToString())
                ,
                Type1 = dt.Rows[i][3].ToString()
                ,
                Type2 = dt.Rows[i][4].ToString()
            });
        }

        return datas;
    }

    [WebMethod]
    public List<rptCustAge> CustomerSaleReport(string searchMode, string fromDate, string toDate)
    {
        List<rptCustAge> datas = new List<rptCustAge>();

        SqlParameterCollection paracol = new SqlCommand().Parameters;
        SqlParameter para;

        para = new SqlParameter();
        para.ParameterName = "@MODE";
        para.Value = searchMode;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@FROM_DATE";
        para.Value = fromDate;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@TO_DATE";
        para.Value = toDate;
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@BRANCH";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString();
        paracol.Add(para);

        DataTable dt = db.ExecuteSpForDT("SP_GET_CUSTOMER_SALE_REPORT", paracol);

        for (int i = 0; i < dt.Rows.Count; i++)
        {
            datas.Add(new rptCustAge
            {
                Value = dt.Rows[i][0].ToString()
                ,
                Qty = Convert.ToDecimal(dt.Rows[i][1].ToString())
                ,
                Amount = Convert.ToDecimal(dt.Rows[i][2].ToString())
            });
        }

        return datas;
    }


    [WebMethod(EnableSession = true)]
    public List<item> GetSupplier(string suppliercode)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_AUTOFILL 'SUPPLIER','" + suppliercode + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _ID = dt.Rows[i]["SupplierCode"].ToString()
                ,
                _description = dt.Rows[i]["Supplier"].ToString()
            });
        }
        return list;
    }

    public class item
    {
        public string _ID { get; set; }
        public string _description { get; set; }
    }


    public decimal value(string val)
    {
        if (val == "")
        {
            return 0;
        }
        else
        {
            return Convert.ToDecimal(val);
        }
    }

    public string MonthName(int number)
    {
        int iMonthNo = number;
        DateTime dtDate = new DateTime(2000, iMonthNo, 1);
        string sMonthName = dtDate.ToString("MMM");
        string sMonthFullName = dtDate.ToString("MMMM");

        return sMonthFullName;
    }

    public class thread
    {
        public string TOTAL_QTY { get; set; }
        public string PURCHASE_AMOUNT { get; set; }
        public string SALE_AMOUNT { get; set; }
        public string BRANCH_ONLINE { get; set; }
        public string USER_ONLINE { get; set; }
        public string PURCHASE_QTY { get; set; }
        public string SALE_QTY { get; set; }
        public string LAST_BILL { get; set; }
    }

    public class UserData
    {
        public string GOODS_IN { get; set; }
        public string GOODS_OUT { get; set; }
        public string SALE_AMOUNT { get; set; }
        public string BILL_COUNT { get; set; }
        public string TOP_USER { get; set; }
    }

    public class dv1
    {
        public string date { get; set; }
        public decimal sales { get; set; }
        public decimal expenses { get; set; }
        public decimal purchase { get; set; }
    }

    public class data
    {
        public string key { get; set; }
        public string color { get; set; }
        public List<XYvalue> values { get; set; }
    }

    public class XYvalue
    {
        public string x { get; set; }
        public string y { get; set; }
    }

    public class salesData {
        public string Month { get; set; }
        public decimal CurrentYear { get; set; }
        public decimal PreviousYear { get; set; }
    }

    public class stockItem
    {
        public string Qty { get; set; }
        public string ProductCode { get; set; }
        public string PrintName { get; set; }
    }

    public class rptData
    {
        public string ID { get; set; }
        public string Value { get; set; }
        public decimal Qty { get; set; }
        public string Type1 { get; set; }
        public string Type2 { get; set; }
    }

    public class rptCustAge
    {
        public string Value { get; set; }
        public decimal Qty { get; set; }
        public decimal Amount { get; set; }
    }
}

