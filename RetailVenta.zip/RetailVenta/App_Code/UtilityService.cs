﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using Retail.DAL;

/// <summary>
/// Summary description for UtilityService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
 [System.Web.Script.Services.ScriptService]
public class UtilityService : System.Web.Services.WebService {

    public UtilityService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    DBClass db = new DBClass();

    [WebMethod(EnableSession=true)]
    public List<Ledger> GetLedger(string name) {
        List<Ledger> list = new List<Ledger>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_PAYMENT_LEDGER_ACCOUNT '" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "','"+name+"'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Ledger
            {
                Id = dt.Rows[i]["ID"].ToString()
                ,
                Name = dt.Rows[i]["Ledger_name"].ToString()
            });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<Invoice> GetInvoice(string id,string search)
    {
        List<Invoice> list = new List<Invoice>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_LEDGER_INVOICE_LIST '" + id + "','"+search+"',"+HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString());
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Invoice
            {
                Id = dt.Rows[i]["Id"].ToString()
                ,
                InvoiceNo = dt.Rows[i]["PurchaseNo"].ToString()
                ,
                InvoiceAmount = dt.Rows[i]["NetAmount"].ToString()
                ,
                InvoiceDate = dt.Rows[i]["PurchaseDate"].ToString()
            });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<Ledger> GetLedgerAccount(string id)
    {
        List<Ledger> list = new List<Ledger>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_PAYMENT_ACCOUNTS '" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Ledger
            {
                Id = dt.Rows[i]["Id"].ToString()
                ,
                Name = dt.Rows[i]["Ledger"].ToString()
            });
        }
        return list;
    }

    [WebMethod(EnableSession = true)]
    public List<Invoice> GetReceiptInvoice(string id, string search)
    {
        List<Invoice> list = new List<Invoice>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_LEDGER_RECEIPT_INVOICE_LIST '" + id + "','" + search + "'," + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString());
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Invoice
            {
                Id = dt.Rows[i]["Id"].ToString()
                ,
                InvoiceNo = dt.Rows[i]["ReceiptNo"].ToString()
                ,
                InvoiceAmount = dt.Rows[i]["NetAmount"].ToString()
                ,
                InvoiceDate = dt.Rows[i]["ReceiptDate"].ToString()
            });
        }
        return list;
    }

    public class Ledger
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }

    public class Invoice
    {
        public string Id { get; set; }
        public string InvoiceNo { get; set; }
        public string InvoiceDate { get; set; }
        public string InvoiceAmount { get; set; }
    }


}
