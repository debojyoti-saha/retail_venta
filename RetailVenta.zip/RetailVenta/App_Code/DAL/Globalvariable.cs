﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Retail.DAL;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI;

public class Globalvariable
{
    public static DataSet DataTables { get; set; }

}

