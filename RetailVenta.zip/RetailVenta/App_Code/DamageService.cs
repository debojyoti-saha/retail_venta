﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using Retail.DAL;
using System.Data.SqlClient;
/// <summary>
/// Summary description for DamageService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
 [System.Web.Script.Services.ScriptService]
public class DamageService : System.Web.Services.WebService {
    DBClass db = new DBClass();
    Cryptography cr = new Cryptography();
    public DamageService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    [WebMethod(EnableSession = true)]
    public List<item> GetProductManual(string productcode, string mode)
    {
        List<item> list = new List<item>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_SALES_ITEM '" + mode + "','" + HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString() + "','" + productcode + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new item
            {
                _itemId = dt.Rows[i]["ItemId"].ToString()
                ,
                _id = dt.Rows[i]["ProductCode"].ToString()
                ,
                _description = dt.Rows[i]["Description"].ToString()
                ,
                _barcode = dt.Rows[i]["BarcodeNo"].ToString()
                ,
                _color = dt.Rows[i]["ColorName"].ToString()
                ,
                _size = dt.Rows[i]["SizeName"].ToString()
                ,
                _brand = dt.Rows[i]["BrandName"].ToString()
                ,
                _design = dt.Rows[i]["DesignName"].ToString()
                ,
                _category = dt.Rows[i]["CategoryName"].ToString()
                ,
                _unit = dt.Rows[i]["Unit"].ToString()
                ,
                _purchaseRate = dt.Rows[i]["PurchaseRate"].ToString()
                ,
                _saleRate = dt.Rows[i]["SaleRate"].ToString()
                ,
                _mrp = dt.Rows[i]["MRP"].ToString()
                ,
                _tax = dt.Rows[i]["Tax"].ToString()
                ,
                _qty = dt.Rows[i]["QTY"].ToString()
                ,
                _qtyType = dt.Rows[i]["QtyType"].ToString()
                ,
                _disc = dt.Rows[i]["DiscountPercent"].ToString()
            });
        }
        return list;
    }

    public class item
    {
        public string _itemId { get; set; }
        public string _id { get; set; }
        public string _description { get; set; }
        public string _barcode { get; set; }
        public string _color { get; set; }
        public string _size { get; set; }
        public string _brand { get; set; }
        public string _category { get; set; }
        public string _design { get; set; }
        public string _unit { get; set; }
        public string _purchaseRate { get; set; }
        public string _saleRate { get; set; }
        public string _mrp { get; set; }
        public string _tax { get; set; }
        public string _qty { get; set; }
        public string _qtyType { get; set; }
        public string _disc { get; set; }
    }


    [WebMethod(EnableSession = true)]
    public string InsertDamage(product product)
    {
                
        DataTable dt_sales_details = new DataTable();
        dt_sales_details.Columns.Add("Id");
        dt_sales_details.Columns.Add("Barcode");
        dt_sales_details.Columns.Add("Amount");
        dt_sales_details.Columns.Add("Discount");
        dt_sales_details.Columns.Add("Qtr");
        dt_sales_details.AcceptChanges();

        List<pro> pr = product.pro;

        foreach (pro p in pr)
        {
            DataRow dr = dt_sales_details.NewRow();
            dr[0] = p.Id;
            dr[1] = p.Barcode;
            dr[2] = p.Amount;
            dr[3] = p.Discount;
            dr[4] = p.Qtr;


            dt_sales_details.Rows.Add(dr);
            dt_sales_details.AcceptChanges();
        }
        SqlParameterCollection paracol = new SqlCommand().Parameters;
        SqlParameter para;

        para = new SqlParameter();
        para.ParameterName = "@SALES_DETAILS";
        para.Value = dt_sales_details;
        paracol.Add(para);
                        
        para = new SqlParameter();
        para.ParameterName = "@BRANCH_CODE";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["Branch"].ToString();
        paracol.Add(para);

        para = new SqlParameter();
        para.ParameterName = "@INSERTED_BY";
        para.Value = HttpContext.Current.Request.Cookies["UserCookies"]["UserId"].ToString();
        paracol.Add(para);

        string message = db.ExecuteSpForInsert("SP_INSERT_DAMAGE_DETAILS", paracol);
        
        return message;
    }

    public class pro
    {
        public string Id { get; set; }
        public string Barcode { get; set; }
        public string Amount { get; set; }
        public string Discount { get; set; }
        public string Qtr { get; set; }
    }

    public class product
    {
       public List<pro> pro { get; set; }
    }

}
