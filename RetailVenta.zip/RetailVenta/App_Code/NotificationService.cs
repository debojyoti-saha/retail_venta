﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using Retail.DAL;

/// <summary>
/// Summary description for NotificationService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
 [System.Web.Script.Services.ScriptService]
public class NotificationService : System.Web.Services.WebService {

    public NotificationService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    DBClass db = new DBClass();

    [WebMethod]
    public List<Notification> getNotification(string userID)
    {
        List<Notification> list = new List<Notification>();
        DataTable dt = new DataTable();
        dt = db.getDataTable("SP_GET_NOTIFICATION '" + userID + "'");
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            list.Add(new Notification
            {
                _Nid = dt.Rows[i]["Nid"].ToString()
                ,
                _NMessage = dt.Rows[i]["NMessage"].ToString()
                ,
                _NSource = dt.Rows[i]["NSource"].ToString()
                ,
                _NRedirectTo = dt.Rows[i]["NRedirectTo"].ToString()
                ,
                _NStatus = dt.Rows[i]["NStatus"].ToString()
            });
        }
        return list;
    }

    [WebMethod]
    public string getNotificationCount(string userID)
    {
        DataTable dt = db.getDataTable("SP_GET_NOTIFICATION_COUNT "+userID);
        return dt.Rows[0][0].ToString();
    }

    [WebMethod]
    public void use(string ID)
    {
        try
        {
            string value = db.returnValue("SP_USE_NOTIFICATION "+ID);
        }
        catch
        {
            return;
        }
    }

    public class Notification
    {
        public string _Nid { get; set; }
        public string _NMessage { get; set; }
        public string _NSource { get; set; }
        public string _NRedirectTo { get; set; }
        public string _NStatus { get; set; }
    }
    
}
